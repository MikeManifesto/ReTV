import queue
import subprocess
import sys
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from pathlib import Path

from . import MEDIA_ROOT, library, scheduler
from .player import ChannelPlayer

AUTO_SCAN_INTERVAL_MS = 3000

ORDER_OPTIONS = [
    ("rotation", "Rotation (least recently played)"),
    ("sequential", "Sequential (by title)"),
    ("random", "Random"),
]

SHORT_SUFFIX = {"rotation": "", "sequential": " [seq]", "random": " [rnd]"}


def days_to_str(days):
    return ",".join(str(d) for d in sorted(days))


def str_to_days(s):
    return [int(x) for x in s.split(",") if x != ""]


def pretty_days(s):
    return ",".join(scheduler.DAY_NAMES[d] for d in str_to_days(s))


def open_path(path):
    path = str(path)
    try:
        if sys.platform.startswith("win"):
            import os
            os.startfile(path)
        elif sys.platform == "darwin":
            subprocess.Popen(["open", path])
        else:
            subprocess.Popen(["xdg-open", path])
    except Exception as e:
        messagebox.showerror("Error", f"Could not open folder:\n{e}")


def _order_submenu(parent, current, callback):
    m = tk.Menu(parent, tearoff=0)
    for opt, label in ORDER_OPTIONS:
        mark = "✓ " if opt == current else "   "
        m.add_command(label=mark + label, command=lambda o=opt: callback(o))
    return m


# ---------------------------------------------------------------------------
# Generic multi-select dialog
# ---------------------------------------------------------------------------
class SelectItemsDialog(tk.Toplevel):
    def __init__(self, master, title, items, selected_ids):
        super().__init__(master)
        self.title(title)
        self.transient(master)
        self.grab_set()
        self.resizable(True, True)
        self.result = None

        self._ids = [iid for iid, _ in items]

        tk.Label(self, text="Select items (Ctrl/Shift-click to multi-select):").pack(
            anchor="w", padx=6, pady=4
        )
        frame = tk.Frame(self)
        frame.pack(fill="both", expand=True, padx=6, pady=4)
        sb = tk.Scrollbar(frame)
        sb.pack(side="right", fill="y")
        self.lb = tk.Listbox(frame, selectmode="multiple", yscrollcommand=sb.set,
                             width=50, height=14)
        self.lb.pack(side="left", fill="both", expand=True)
        sb.config(command=self.lb.yview)

        for iid, label in items:
            self.lb.insert("end", label)
            if iid in selected_ids:
                self.lb.selection_set("end")

        bf = tk.Frame(self)
        bf.pack(fill="x", pady=6, padx=6)
        tk.Button(bf, text="Select all",
                  command=lambda: self.lb.selection_set(0, "end")).pack(side="left")
        tk.Button(bf, text="Clear",
                  command=lambda: self.lb.selection_clear(0, "end")).pack(side="left", padx=4)
        tk.Button(bf, text="OK", command=self._ok).pack(side="right")
        tk.Button(bf, text="Cancel", command=self.destroy).pack(side="right", padx=4)

    def _ok(self):
        self.result = {self._ids[i] for i in self.lb.curselection()}
        self.destroy()


# ---------------------------------------------------------------------------
# Channel dialog
# ---------------------------------------------------------------------------
class ChannelDialog(tk.Toplevel):
    def __init__(self, master, db):
        super().__init__(master)
        self.db = db
        self.title("New Channel")
        self.transient(master)
        self.grab_set()
        self.resizable(False, False)

        self.name_var = tk.StringVar()
        self.num_var = tk.StringVar()
        self.logo_path = None

        tk.Label(self, text="Name:").grid(row=0, column=0, sticky="e", padx=6, pady=6)
        tk.Entry(self, textvariable=self.name_var, width=30).grid(row=0, column=1, padx=6, pady=6)
        tk.Label(self, text="Number:").grid(row=1, column=0, sticky="e", padx=6, pady=6)
        tk.Entry(self, textvariable=self.num_var, width=10).grid(
            row=1, column=1, sticky="w", padx=6, pady=6
        )
        tk.Label(self, text="Logo:").grid(row=2, column=0, sticky="e", padx=6, pady=6)
        lf = tk.Frame(self)
        lf.grid(row=2, column=1, sticky="w", padx=6, pady=6)
        self.logo_label = tk.Label(lf, text="(none)", width=18, anchor="w")
        self.logo_label.pack(side="left")
        tk.Button(lf, text="Browse…", command=self._pick_logo).pack(side="left")
        bf = tk.Frame(self)
        bf.grid(row=3, column=0, columnspan=2, pady=8)
        tk.Button(bf, text="Create", command=self._ok).pack(side="left", padx=4)
        tk.Button(bf, text="Cancel", command=self.destroy).pack(side="left", padx=4)

    def _pick_logo(self):
        p = filedialog.askopenfilename(
            parent=self, title="Channel logo",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"), ("All files", "*.*")],
        )
        if p:
            self.logo_path = p
            self.logo_label.config(text=Path(p).name)

    def _ok(self):
        name = self.name_var.get().strip()
        if not name:
            messagebox.showerror("Error", "Name is required.", parent=self)
            return
        if any(library.sanitize(c["name"]) == library.sanitize(name)
               for c in self.db.get_channels()):
            messagebox.showerror(
                "Error", "A channel whose folder name matches already exists.", parent=self
            )
            return
        number = None
        if self.num_var.get().strip():
            try:
                number = int(self.num_var.get())
            except ValueError:
                messagebox.showerror("Error", "Channel number must be an integer.", parent=self)
                return
        try:
            cid = self.db.add_channel(name, number)
            new_ch = self.db.get_channel(cid)
            library.ensure_channel_tree(new_ch)
            if self.logo_path:
                library.set_channel_logo(new_ch, self.logo_path)
        except Exception as e:
            messagebox.showerror("Error", str(e), parent=self)
            return
        self.destroy()


# ---------------------------------------------------------------------------
# Block dialog
# ---------------------------------------------------------------------------
class BlockDialog(tk.Toplevel):
    def __init__(self, master, db, channel):
        super().__init__(master)
        self.db = db
        self.channel = channel
        self.title(f"New Block on {channel['name']}")
        self.transient(master)
        self.grab_set()
        self.resizable(False, False)

        self.name_var = tk.StringVar()
        self.start_var = tk.StringVar(value="18:00")
        self.dur_var = tk.StringVar(value="120")
        self.shuffle_var = tk.BooleanVar(value=False)
        self.day_vars = [tk.BooleanVar(value=True) for _ in range(7)]

        row = 0
        tk.Label(self, text="Name:").grid(row=row, column=0, sticky="e", padx=6, pady=4)
        tk.Entry(self, textvariable=self.name_var, width=30).grid(
            row=row, column=1, columnspan=3, sticky="w", padx=6, pady=4
        )
        row += 1
        tk.Label(self, text="Days:").grid(row=row, column=0, sticky="ne", padx=6, pady=4)
        df = tk.Frame(self)
        df.grid(row=row, column=1, columnspan=3, sticky="w")
        for i, dn in enumerate(scheduler.DAY_NAMES):
            tk.Checkbutton(df, text=dn, variable=self.day_vars[i]).grid(row=0, column=i)
        row += 1
        tk.Label(self, text="Start (HH:MM):").grid(row=row, column=0, sticky="e", padx=6, pady=4)
        tk.Entry(self, textvariable=self.start_var, width=8).grid(
            row=row, column=1, sticky="w", padx=6, pady=4
        )
        row += 1
        tk.Label(self, text="Duration (min):").grid(row=row, column=0, sticky="e", padx=6, pady=4)
        tk.Entry(self, textvariable=self.dur_var, width=8).grid(
            row=row, column=1, sticky="w", padx=6, pady=4
        )
        row += 1
        tk.Checkbutton(self, text="Randomize show order per block",
                       variable=self.shuffle_var).grid(
            row=row, column=1, columnspan=3, sticky="w", padx=6, pady=4
        )
        row += 1
        bf = tk.Frame(self)
        bf.grid(row=row, column=0, columnspan=4, pady=8)
        tk.Button(bf, text="Create", command=self._ok).pack(side="left", padx=4)
        tk.Button(bf, text="Cancel", command=self.destroy).pack(side="left", padx=4)

    def _ok(self):
        name = self.name_var.get().strip()
        if not name:
            messagebox.showerror("Error", "Name is required.", parent=self)
            return
        if any(library.sanitize(b["name"]) == library.sanitize(name)
               for b in self.db.get_blocks(self.channel["id"])):
            messagebox.showerror(
                "Error", "A block with that name already exists on this channel.", parent=self
            )
            return
        days = [i for i, v in enumerate(self.day_vars) if v.get()]
        if not days:
            messagebox.showerror("Error", "Pick at least one day.", parent=self)
            return
        try:
            h, m = map(int, self.start_var.get().strip().split(":"))
            assert 0 <= h < 24 and 0 <= m < 60
        except Exception:
            messagebox.showerror("Error", "Start must be HH:MM.", parent=self)
            return
        try:
            dur = int(self.dur_var.get())
            assert dur > 0
        except Exception:
            messagebox.showerror("Error", "Duration must be a positive integer.", parent=self)
            return
        self.db.add_block(
            self.channel["id"], name, days_to_str(days),
            f"{h:02d}:{m:02d}", dur, self.shuffle_var.get(),
        )
        self.destroy()


# ---------------------------------------------------------------------------
# Add media dialog
# ---------------------------------------------------------------------------
class MediaDialog(tk.Toplevel):
    def __init__(self, master, db, channel=None):
        super().__init__(master)
        self.db = db
        self.title("Add Media")
        self.transient(master)
        self.grab_set()
        self.resizable(False, False)

        self.files = []
        self.channel_var = tk.StringVar()
        self.kind_var = tk.StringVar(value="episode")
        self.target_var = tk.StringVar()
        self.new_name_var = tk.StringVar()

        self.channels = self.db.get_channels()
        if not self.channels:
            messagebox.showinfo("No channels", "Create a channel first.", parent=self)
            self.destroy()
            return
        self.channel_var.set(channel["name"] if channel else self.channels[0]["name"])

        row = 0
        tk.Label(self, text="Channel:").grid(row=row, column=0, sticky="e", padx=6, pady=4)
        cb = ttk.Combobox(self, textvariable=self.channel_var,
                          values=[c["name"] for c in self.channels],
                          state="readonly", width=30)
        cb.grid(row=row, column=1, columnspan=2, sticky="w", padx=6, pady=4)
        cb.bind("<<ComboboxSelected>>", lambda e: self._refresh_targets())
        row += 1

        tk.Label(self, text="Kind:").grid(row=row, column=0, sticky="e", padx=6, pady=4)
        kcb = ttk.Combobox(
            self, textvariable=self.kind_var,
            values=["episode", "show bumper", "bumper", "commercial"],
            state="readonly", width=30,
        )
        kcb.grid(row=row, column=1, columnspan=2, sticky="w", padx=6, pady=4)
        kcb.bind("<<ComboboxSelected>>", lambda e: self._refresh_targets())
        row += 1

        self.target_label = tk.Label(self, text="Show:")
        self.target_label.grid(row=row, column=0, sticky="e", padx=6, pady=4)
        self.target_cb = ttk.Combobox(self, textvariable=self.target_var,
                                      state="readonly", width=30)
        self.target_cb.grid(row=row, column=1, columnspan=2, sticky="w", padx=6, pady=4)
        row += 1

        self.new_label = tk.Label(self, text="New name:")
        self.new_label.grid(row=row, column=0, sticky="e", padx=6, pady=4)
        self.new_entry = tk.Entry(self, textvariable=self.new_name_var, width=32)
        self.new_entry.grid(row=row, column=1, columnspan=2, sticky="w", padx=6, pady=4)
        row += 1

        self.file_label = tk.Label(self, text="No files selected")
        self.file_label.grid(row=row, column=0, columnspan=3, sticky="w", padx=6, pady=4)
        row += 1

        bf = tk.Frame(self)
        bf.grid(row=row, column=0, columnspan=3, pady=8)
        tk.Button(bf, text="Choose Files…", command=self._choose_files).pack(side="left", padx=4)
        tk.Button(bf, text="Import", command=self._import).pack(side="left", padx=4)
        tk.Button(bf, text="Cancel", command=self.destroy).pack(side="left", padx=4)

        self._refresh_targets()

    def _current_channel(self):
        for c in self.channels:
            if c["name"] == self.channel_var.get():
                return c
        return None

    def _refresh_targets(self):
        ch = self._current_channel()
        if ch is None:
            return
        kind = self.kind_var.get()
        if kind in ("episode", "show bumper"):
            items = [s["name"] for s in self.db.get_shows_for_channel(ch["id"])]
            self.target_label.config(text="Show:")
        elif kind == "bumper":
            items = [g["name"] for g in self.db.get_bumper_groups(ch["id"])]
            self.target_label.config(text="Bumper group:")
        else:
            items = [g["name"] for g in self.db.get_commercial_groups(ch["id"])]
            self.target_label.config(text="Commercial group:")
        self.target_cb["values"] = items + ["<new>"]
        self.target_var.set(items[0] if items else "<new>")

    def _choose_files(self):
        paths = filedialog.askopenfilenames(
            parent=self, title="Select video files",
            filetypes=[("Video files", "*.mp4 *.mkv *.avi *.mov *.webm *.m4v *.ts *.mpg *.mpeg"),
                       ("All files", "*.*")],
        )
        if paths:
            self.files = list(paths)
            self.file_label.config(text=f"{len(self.files)} file(s) selected")

    def _import(self):
        if not self.files:
            messagebox.showerror("Error", "Choose files first.", parent=self)
            return
        ch = self._current_channel()
        kind = self.kind_var.get()

        show = None
        bumper_group = None
        commercial_group = None

        if kind in ("episode", "show bumper"):
            if self.target_var.get() == "<new>":
                new_name = self.new_name_var.get().strip()
                if not new_name:
                    messagebox.showerror("Error", "Enter a show name.", parent=self)
                    return
                existing = self.db.find_show(ch["id"], new_name)
                if existing:
                    show = existing
                else:
                    sid = self.db.add_show(ch["id"], new_name)
                    show = self.db.query_one("SELECT * FROM shows WHERE id=?", (sid,))
                    library.ensure_show_tree(ch, show)
            else:
                for s in self.db.get_shows_for_channel(ch["id"]):
                    if s["name"] == self.target_var.get():
                        show = s
                        break
            db_kind = "episode" if kind == "episode" else "show_bumper"

        elif kind == "bumper":
            if self.target_var.get() == "<new>":
                new_name = self.new_name_var.get().strip()
                if not new_name:
                    messagebox.showerror("Error", "Enter a group name.", parent=self)
                    return
                for g in self.db.get_bumper_groups(ch["id"]):
                    if g["name"] == new_name:
                        bumper_group = g
                        break
                else:
                    gid = self.db.add_bumper_group(ch["id"], new_name)
                    bumper_group = self.db.query_one(
                        "SELECT * FROM bumper_groups WHERE id=?", (gid,)
                    )
                    library.ensure_bumper_group_dir(ch, new_name)
            else:
                for g in self.db.get_bumper_groups(ch["id"]):
                    if g["name"] == self.target_var.get():
                        bumper_group = g
                        break
            db_kind = "bumper"

        else:  # commercial
            if self.target_var.get() == "<new>":
                new_name = self.new_name_var.get().strip()
                if not new_name:
                    messagebox.showerror("Error", "Enter a group name.", parent=self)
                    return
                for g in self.db.get_commercial_groups(ch["id"]):
                    if g["name"] == new_name:
                        commercial_group = g
                        break
                else:
                    gid = self.db.add_commercial_group(ch["id"], new_name)
                    commercial_group = self.db.query_one(
                        "SELECT * FROM commercial_groups WHERE id=?", (gid,)
                    )
                    library.ensure_commercial_group_dir(ch, new_name)
            else:
                for g in self.db.get_commercial_groups(ch["id"]):
                    if g["name"] == self.target_var.get():
                        commercial_group = g
                        break
            db_kind = "commercial"

        try:
            n = library.import_files(
                self.db, self.files, ch, db_kind,
                show=show, bumper_group=bumper_group, commercial_group=commercial_group,
            )
        except Exception as e:
            messagebox.showerror("Import failed", str(e), parent=self)
            return
        messagebox.showinfo("Imported", f"Imported {n} file(s).", parent=self)
        self.destroy()


# ---------------------------------------------------------------------------
# Main window
# ---------------------------------------------------------------------------
class App(tk.Tk):
    def __init__(self, db):
        super().__init__()
        self.withdraw()                  # hidden until start_headless()/show_menu()
        self._menu_visible = False
        self._aborted = False

        self.db = db
        self.title("TV Emulator")
        self.geometry("1200x720")

        self._auto_scan_enabled = tk.BooleanVar(value=True)
        self._auto_scan_in_progress = False
        self._scan_queue = queue.Queue()
        self._tv = None
        self._tv_queue = queue.Queue()

        if not self._run_migration_if_needed():
            self._aborted = True
            self.after(0, self.destroy)
            return

        self._build_toolbar()
        self._build_body()
        self._build_status()
        self.protocol("WM_DELETE_WINDOW", self._on_close)

        self.refresh_channels()
        self._auto_scan_tick()
        self._poll_tv()

    # ------------------------------------------------------------------
    # Menu visibility (mpv is the primary window; Tk is the menu)
    # ------------------------------------------------------------------
    def show_menu(self):
        self._menu_visible = True
        try:
            self.deiconify()
            self.lift()
            self.focus_force()
        except Exception:
            pass

    def hide_menu(self):
        self._menu_visible = False
        try:
            self.withdraw()
        except Exception:
            pass

    # ------------------------------------------------------------------
    # Startup
    # ------------------------------------------------------------------
    def start_headless(self):
        """Start the mpv player on the last-watched channel without showing
        the menu. The menu can be reopened later with the M key inside mpv."""
        if self._aborted:
            return
        last_id = self.db.get_setting("last_channel")
        ch = None
        if last_id:
            try:
                ch = self.db.get_channel(int(last_id))
            except (ValueError, TypeError):
                ch = None
        if ch is None:
            channels = self.db.get_channels()
            if channels:
                ch = channels[0]
        if ch is None:
            # Nothing to watch yet; show the menu so the user can set things up.
            self.show_menu()
            return
        self._launch_player(ch)

    def _launch_player(self, ch):
        """Ensure a player is running and tuned to `ch`. Returns True on success."""
        if self._tv is not None:
            if self._tv.alive:
                self._tv.tune(ch)
                return True
            try:
                self._tv.stop()
            except Exception:
                pass
            self._tv = None
        try:
            self._tv = ChannelPlayer(
                self.db, ch["id"], self._tv_status, self._tv_closed,
                on_menu=self._tv_menu,
            )
        except ImportError:
            self.show_menu()
            messagebox.showerror(
                "mpv missing",
                "python-mpv (and libmpv) is required.\n\npip install python-mpv",
                parent=self,
            )
            return False
        except OSError as e:
            self.show_menu()
            messagebox.showerror("libmpv not found", str(e), parent=self)
            return False
        except Exception as e:
            self.show_menu()
            messagebox.showerror("Could not start mpv", str(e), parent=self)
            return False
        self._tv.start()
        return True

    # ------------------------------------------------------------------
    def _run_migration_if_needed(self):
        if not library.has_old_layout():
            return True
        self.show_menu()
        if not messagebox.askyesno(
            "Migrate folder layout",
            "The old block-scoped folder layout was detected.\n\n"
            "This will MOVE files to the new layout:\n\n"
            "  blocks/B/shows/S/episodes/* → shows/S/*\n"
            "  blocks/B/shows/S/bumpers/*  → shows/S/bumpers/*\n"
            "  blocks/B/bumpers/*          → bumpers/B bumpers/*\n"
            "  bumpers/*                   → bumpers/Channel bumpers/*\n"
            "  commercials/*               → commercials/Default/*\n\n"
            "The database has already been migrated.\n"
            "Back up your media folder first if unsure."
        ):
            messagebox.showinfo(
                "Migration skipped",
                "The app can't run with the old layout.\n"
                "Please move files manually, then restart."
            )
            return False
        try:
            stats = library.migrate_old_layout(self.db)
        except Exception as e:
            messagebox.showerror("Migration failed", str(e))
            return False
        if stats:
            msg = f"Moved {stats['moved']} file(s)."
            if stats["errors"]:
                msg += f"\n\n{len(stats['errors'])} error(s):\n" + "\n".join(stats["errors"][:5])
            messagebox.showinfo("Migration complete", msg)
        self.hide_menu()
        return True

    def _build_toolbar(self):
        bar = tk.Frame(self)
        bar.pack(fill="x", side="top")
        tk.Button(bar, text="New Channel", command=self.new_channel).pack(side="left", padx=4, pady=4)
        tk.Button(bar, text="New Block", command=self.new_block).pack(side="left", padx=4, pady=4)
        tk.Button(bar, text="Add Media", command=self.add_media).pack(side="left", padx=4, pady=4)
        tk.Button(bar, text="Delete Channel", command=self.delete_channel).pack(side="left", padx=4, pady=4)
        tk.Label(bar, text=" | ").pack(side="left")
        tk.Button(bar, text="Scan Now", command=self._scan_clicked).pack(side="left", padx=4, pady=4)
        tk.Checkbutton(bar, text="Auto-scan", variable=self._auto_scan_enabled).pack(side="left", padx=4)
        tk.Button(bar, text="Clean Missing Files",
                  command=self.clean_missing_clicked).pack(side="left", padx=4, pady=4)
        tk.Button(bar, text="Open Media Folder",
                  command=self.open_media_folder).pack(side="left", padx=4, pady=4)
        tk.Button(bar, text="▶ Watch Channel",
                  command=self.watch_selected).pack(side="right", padx=4, pady=4)

    def _build_body(self):
        pane = tk.PanedWindow(self, orient="horizontal")
        pane.pack(fill="both", expand=True)

        left = tk.Frame(pane)
        tk.Label(left, text="Channels").pack(anchor="w")

        # ---- donation box: clickable Ko-fi link, pinned to the bottom ----
        import webbrowser

        KO_FI_URL  = "https://ko-fi.com/seanderiko"
        COL_NORMAL = "#e53935"
        COL_HOVER  = "#d32f2f"
        COL_PRESS  = "#b71c1c"
        FG_WHITE   = "#000000"

        donate = tk.Frame(
            left,
            bg=COL_NORMAL,
            relief="raised",
            bd=2,
            padx=8, pady=8,
            cursor="hand2",
        )
        donate.pack(side="bottom", fill="x", pady=(6, 0))

        self._cofi_img = None
        try:
            from PIL import Image, ImageTk
            _cofi_path = Path(__file__).resolve().parent.parent / "assets" / "cofi-logo.png"
            if _cofi_path.exists():
                _im = Image.open(_cofi_path)
                _im.thumbnail((56, 56))
                self._cofi_img = ImageTk.PhotoImage(_im)
        except Exception:
            self._cofi_img = None

        if self._cofi_img is not None:
            logo_lbl = tk.Label(donate, image=self._cofi_img, bg=COL_NORMAL,
                                bd=0, cursor="hand2")
            logo_lbl.pack(side="left", padx=(0, 10))
        else:
            logo_lbl = tk.Label(donate, text="☕", bg=COL_NORMAL, fg=FG_WHITE,
                                bd=0, font=("Segoe UI", 22, "bold"), cursor="hand2")
            logo_lbl.pack(side="left", padx=(0, 10))

        text_col = tk.Frame(donate, bg=COL_NORMAL, bd=0, cursor="hand2")
        text_col.pack(side="left", fill="x", expand=True)

        top_lbl = tk.Label(
            text_col, text="do you like ReTV?", anchor="w",
            fg=FG_WHITE, bg=COL_NORMAL, bd=0,
            font=("Segoe UI", 10, "bold"), cursor="hand2",
        )
        top_lbl.pack(side="top", fill="x")

        bot_lbl = tk.Label(
            text_col, text="buy me a coffie!", anchor="w",
            fg=FG_WHITE, bg=COL_NORMAL, bd=0,
            font=("Segoe UI", 14, "bold italic"), cursor="hand2",
        )
        bot_lbl.pack(side="top", fill="x")

        _bg_widgets = [donate, logo_lbl, text_col, top_lbl, bot_lbl]

        def _apply_state(bg, sunken=False):
            for w in _bg_widgets:
                try:
                    w.configure(bg=bg)
                except tk.TclError:
                    pass
            try:
                donate.configure(relief="sunken" if sunken else "raised")
            except tk.TclError:
                pass

        def _open_kofi(_event=None):
            webbrowser.open(KO_FI_URL)

        def _still_inside(e):
            x, y = e.x_root, e.y_root
            wx, wy = donate.winfo_rootx(), donate.winfo_rooty()
            return (wx <= x < wx + donate.winfo_width()
                    and wy <= y < wy + donate.winfo_height())

        def _on_enter(_e):
            _apply_state(COL_HOVER)

        def _on_leave(e):
            if not _still_inside(e):
                _apply_state(COL_NORMAL)

        def _on_press(_e):
            _apply_state(COL_PRESS, sunken=True)

        def _on_release(e):
            if _still_inside(e):
                _apply_state(COL_HOVER)
                _open_kofi()
            else:
                _apply_state(COL_NORMAL)

        for w in _bg_widgets:
            w.bind("<Enter>", _on_enter)
            w.bind("<Leave>", _on_leave)
            w.bind("<ButtonPress-1>", _on_press)
            w.bind("<ButtonRelease-1>", _on_release)

        self.channel_list = tk.Listbox(left, exportselection=False)
        self.channel_list.pack(fill="both", expand=True)
        self.channel_list.bind("<<ListboxSelect>>", lambda e: self.on_channel_selected())
        self.channel_list.bind("<Button-2>", lambda e: self._channel_menu(e))
        self.channel_list.bind("<Button-3>", lambda e: self._channel_menu(e))
        pane.add(left, width=260)

        right = tk.Frame(pane)
        nb = ttk.Notebook(right)
        nb.pack(fill="both", expand=True)

        self.schedule_tab = tk.Frame(nb)
        nb.add(self.schedule_tab, text="Schedule")

        cols = ("block", "days", "start", "dur", "assign")
        self.block_tree = ttk.Treeview(self.schedule_tab, columns=cols, show="headings")
        for c, label, w in [
            ("block", "Block", 180), ("days", "Days", 140),
            ("start", "Start", 80), ("dur", "Duration", 90),
            ("assign", "Assignments", 340),
        ]:
            self.block_tree.heading(c, text=label)
            self.block_tree.column(c, width=w, anchor="w")
        self.block_tree.pack(fill="both", expand=True, side="top")
        self.block_tree.bind("<Button-2>", lambda e: self._block_menu(e))
        self.block_tree.bind("<Button-3>", lambda e: self._block_menu(e))

        bbar = tk.Frame(self.schedule_tab)
        bbar.pack(fill="x")
        tk.Button(bbar, text="Add Block", command=self.new_block).pack(side="left", padx=4, pady=4)
        tk.Button(bbar, text="Delete Block", command=self.delete_block).pack(side="left", padx=4, pady=4)
        tk.Button(bbar, text="Assign Shows…",
                  command=self._assign_shows_selected).pack(side="left", padx=4, pady=4)
        tk.Button(bbar, text="Assign Bumper Groups…",
                  command=self._assign_bumpers_selected).pack(side="left", padx=4, pady=4)
        tk.Button(bbar, text="Assign Commercial Groups…",
                  command=self._assign_commercials_selected).pack(side="left", padx=4, pady=4)

        self.library_tab = tk.Frame(nb)
        nb.add(self.library_tab, text="Library")
        lcols = ("kind", "name", "dur")
        self.media_tree = ttk.Treeview(self.library_tab, columns=lcols, show="tree headings")
        self.media_tree.heading("#0", text="Item")
        self.media_tree.column("#0", width=300)
        self.media_tree.heading("kind", text="Kind")
        self.media_tree.column("kind", width=120)
        self.media_tree.heading("name", text="Title")
        self.media_tree.column("name", width=300)
        self.media_tree.heading("dur", text="Duration")
        self.media_tree.column("dur", width=90)
        self.media_tree.pack(fill="both", expand=True)
        self.media_tree.bind("<Button-2>", lambda e: self._library_menu(e))
        self.media_tree.bind("<Button-3>", lambda e: self._library_menu(e))

        pane.add(right)

    def _build_status(self):
        self.status = tk.Label(self, text="Ready", anchor="w", relief="sunken")
        self.status.pack(fill="x", side="bottom")

    # ------------------------------------------------------------------
    # Auto-scan
    # ------------------------------------------------------------------
    def _auto_scan_tick(self):
        try:
            while True:
                stats = self._scan_queue.get_nowait()
                self._auto_scan_in_progress = False
                self._apply_scan_stats(stats)
        except queue.Empty:
            pass
        if self._auto_scan_enabled.get() and not self._auto_scan_in_progress:
            self._auto_scan_in_progress = True
            threading.Thread(target=self._scan_worker, daemon=True).start()
        self.after(AUTO_SCAN_INTERVAL_MS, self._auto_scan_tick)

    def _scan_worker(self):
        try:
            stats = library.scan_and_import(self.db)
        except Exception as e:
            stats = {"error": str(e)}
        self._scan_queue.put(stats)

    def _apply_scan_stats(self, stats):
        if stats.get("error"):
            self.status.config(text=f"Scan error: {stats['error']}")
            return
        if any(stats.values()):
            self.refresh_all()
            self.status.config(text=(
                f"Library updated — +{stats['channels']} channel(s), "
                f"+{stats['shows']} show(s), +{stats['bumper_groups']} bumper group(s), "
                f"+{stats['commercial_groups']} commercial group(s), +{stats['files']} file(s)"
            ))

    def _scan_clicked(self):
        if self._auto_scan_in_progress:
            self.status.config(text="A scan is already running.")
            return
        self._auto_scan_in_progress = True
        self.status.config(text="Scanning…")
        self.update_idletasks()
        try:
            stats = library.scan_and_import(self.db)
        except Exception as e:
            stats = {"error": str(e)}
        finally:
            self._auto_scan_in_progress = False
        self._apply_scan_stats(stats)
        if not stats.get("error") and not any(stats.values()):
            self.status.config(text="Scan complete — nothing new.")

    # ------------------------------------------------------------------
    def _selected_channel(self):
        sel = self.channel_list.curselection()
        return self._channels[sel[0]] if sel else None

    def _selected_block(self):
        sel = self.block_tree.selection()
        return self.db.query_one("SELECT * FROM blocks WHERE id=?", (int(sel[0]),)) if sel else None

    # ------------------------------------------------------------------
    # Menus
    # ------------------------------------------------------------------
    def _channel_menu(self, event):
        idx = self.channel_list.nearest(event.y)
        if idx < 0 or idx >= len(self._channels):
            return
        self.channel_list.selection_clear(0, "end")
        self.channel_list.selection_set(idx)
        self.on_channel_selected()
        ch = self._channels[idx]
        m = tk.Menu(self, tearoff=0)
        m.add_command(label="Open channel folder",
                      command=lambda: open_path(library.ensure_channel_tree(ch)))
        m.add_command(label="Open shows folder",
                      command=lambda: open_path(library.ensure_channel_tree(ch) / "shows"))
        m.add_command(label="Open bumpers folder",
                      command=lambda: open_path(library.ensure_channel_tree(ch) / "bumpers"))
        m.add_command(label="Open commercials folder",
                      command=lambda: open_path(library.ensure_channel_tree(ch) / "commercials"))
        m.add_cascade(label="Bumper order",
                      menu=_order_submenu(
                          m, ch["bumper_order"],
                          lambda o: self._set_channel_asset_order(ch, "bumper_order", o),
                      ))
        m.add_cascade(label="Commercial order",
                      menu=_order_submenu(
                          m, ch["commercial_order"],
                          lambda o: self._set_channel_asset_order(ch, "commercial_order", o),
                      ))
        has_logo = library.find_channel_logo(ch) is not None
        m.add_command(label="Change channel logo…" if has_logo else "Set channel logo…",
                      command=lambda: self._set_channel_logo(ch))
        if has_logo:
            m.add_command(label="Remove channel logo",
                          command=lambda: self._remove_channel_logo(ch))
        m.add_command(label="Rename channel…", command=lambda: self._rename_channel(ch))
        m.add_separator()
        m.add_command(label="Delete channel…", command=self.delete_channel)
        m.tk_popup(event.x_root, event.y_root)

    def _block_menu(self, event):
        row = self.block_tree.identify_row(event.y)
        if not row:
            return
        self.block_tree.selection_set(row)
        ch = self._selected_channel()
        block = self._selected_block()
        if not (ch and block):
            return
        m = tk.Menu(self, tearoff=0)
        m.add_command(label="Assign shows…",
                      command=lambda: self._assign_shows(ch, block))
        m.add_command(label="Assign bumper groups…",
                      command=lambda: self._assign_bumpers(ch, block))
        m.add_command(label="Assign commercial groups…",
                      command=lambda: self._assign_commercials(ch, block))
        m.add_separator()
        m.add_command(
            label=("Unshuffle show order" if block["shuffle_shows"]
                   else "Randomize show order"),
            command=lambda: self._toggle_block_shuffle(block),
        )
        m.add_command(label="Rename block…",
                      command=lambda: self._rename_block(ch, block))
        m.add_separator()
        m.add_command(label="Delete block…", command=self.delete_block)
        m.tk_popup(event.x_root, event.y_root)

    def _library_menu(self, event):
        row = self.media_tree.identify_row(event.y)
        if not row:
            return
        self.media_tree.selection_set(row)
        ch = self._selected_channel()
        if not ch:
            return
        iid = str(row)
        m = tk.Menu(self, tearoff=0)

        if iid.startswith("show-"):
            sid = int(iid.split("-", 1)[1])
            show = self.db.query_one("SELECT * FROM shows WHERE id=?", (sid,))
            if not show:
                return
            m.add_command(label="Open show folder",
                          command=lambda: open_path(library.ensure_show_tree(ch, show)))
            m.add_cascade(label="Episode order",
                          menu=_order_submenu(
                              m, show["episode_order"],
                              lambda o: self._set_show_episode_order(show, o)))
            m.add_command(label="Rename show…",
                          command=lambda: self._rename_show(ch, show))
        elif iid.startswith("bg-"):
            gid = int(iid.split("-", 1)[1])
            g = self.db.query_one("SELECT * FROM bumper_groups WHERE id=?", (gid,))
            if not g:
                return
            m.add_command(label="Open bumper group folder",
                          command=lambda: open_path(library.ensure_bumper_group_dir(ch, g["name"])))
            m.add_command(label="Rename group…",
                          command=lambda: self._rename_bumper_group(ch, g))
        elif iid.startswith("cg-"):
            gid = int(iid.split("-", 1)[1])
            g = self.db.query_one("SELECT * FROM commercial_groups WHERE id=?", (gid,))
            if not g:
                return
            m.add_command(label="Open commercial group folder",
                          command=lambda: open_path(library.ensure_commercial_group_dir(ch, g["name"])))
            m.add_command(label="Rename group…",
                          command=lambda: self._rename_commercial_group(ch, g))
        else:
            return
        m.tk_popup(event.x_root, event.y_root)

    # ------------------------------------------------------------------
    # Assignments
    # ------------------------------------------------------------------
    def _assign_shows(self, ch, block):
        items = [(s["id"], s["name"]) for s in self.db.get_shows_for_channel(ch["id"])]
        if not items:
            messagebox.showinfo("No shows", "This channel has no shows yet.", parent=self)
            return
        current = {s["id"] for s in self.db.get_block_shows(block["id"])}
        dlg = SelectItemsDialog(self, f"Shows for '{block['name']}'", items, current)
        self.wait_window(dlg)
        if dlg.result is None:
            return
        self.db.set_block_shows(block["id"], dlg.result)
        self.refresh_blocks()

    def _assign_bumpers(self, ch, block):
        items = [(g["id"], g["name"]) for g in self.db.get_bumper_groups(ch["id"])]
        if not items:
            messagebox.showinfo("No bumper groups",
                                "Create a subfolder under bumpers/ first.", parent=self)
            return
        current = {g["id"] for g in self.db.get_block_bumper_groups(block["id"])}
        dlg = SelectItemsDialog(self, f"Bumper groups for '{block['name']}'", items, current)
        self.wait_window(dlg)
        if dlg.result is None:
            return
        self.db.set_block_bumper_groups(block["id"], dlg.result)
        self.refresh_blocks()

    def _assign_commercials(self, ch, block):
        items = [(g["id"], g["name"]) for g in self.db.get_commercial_groups(ch["id"])]
        if not items:
            messagebox.showinfo("No commercial groups",
                                "Create a subfolder under commercials/ first.", parent=self)
            return
        current = {g["id"] for g in self.db.get_block_commercial_groups(block["id"])}
        dlg = SelectItemsDialog(self, f"Commercial groups for '{block['name']}'", items, current)
        self.wait_window(dlg)
        if dlg.result is None:
            return
        self.db.set_block_commercial_groups(block["id"], dlg.result)
        self.refresh_blocks()

    def _assign_shows_selected(self):
        ch, block = self._selected_channel(), self._selected_block()
        if not (ch and block):
            messagebox.showerror("No block", "Select a block first.")
            return
        self._assign_shows(ch, block)

    def _assign_bumpers_selected(self):
        ch, block = self._selected_channel(), self._selected_block()
        if not (ch and block):
            messagebox.showerror("No block", "Select a block first.")
            return
        self._assign_bumpers(ch, block)

    def _assign_commercials_selected(self):
        ch, block = self._selected_channel(), self._selected_block()
        if not (ch and block):
            messagebox.showerror("No block", "Select a block first.")
            return
        self._assign_commercials(ch, block)

    # ------------------------------------------------------------------
    def _set_show_episode_order(self, show, order):
        self.db.execute("UPDATE shows SET episode_order=? WHERE id=?", (order, show["id"]))
        self.refresh_library()
        self.status.config(text=f"Episode order for '{show['name']}': {order}")

    def _set_channel_asset_order(self, ch, field, order):
        self.db.execute(f"UPDATE channels SET {field}=? WHERE id=?", (order, ch["id"]))
        pretty = "Bumper" if field == "bumper_order" else "Commercial"
        self.status.config(text=f"{pretty} order for '{ch['name']}': {order}")

    def _toggle_block_shuffle(self, block):
        new_val = 0 if block["shuffle_shows"] else 1
        self.db.execute("UPDATE blocks SET shuffle_shows=? WHERE id=?", (new_val, block["id"]))
        self.db.clear_anchors_for_block(block["id"])
        self.refresh_blocks()

    # ------------------------------------------------------------------
    def _set_channel_logo(self, ch):
        p = filedialog.askopenfilename(
            parent=self, title=f"Logo for '{ch['name']}'",
            filetypes=[("Images", "*.png *.jpg *.jpeg *.webp *.bmp *.gif"), ("All files", "*.*")],
        )
        if not p:
            return
        try:
            library.set_channel_logo(ch, p)
        except Exception as e:
            messagebox.showerror("Logo", str(e))
            return
        self.status.config(text=f"Logo set for '{ch['name']}'.")

    def _remove_channel_logo(self, ch):
        library.clear_channel_logo(ch)
        self.status.config(text=f"Logo removed from '{ch['name']}'.")

    def _rename_channel(self, ch):
        new_name = simpledialog.askstring(
            "Rename channel", f"New name for '{ch['name']}':",
            initialvalue=ch["name"], parent=self,
        )
        if not new_name:
            return
        new_name = new_name.strip()
        if not new_name or new_name == ch["name"]:
            return
        try:
            library.rename_channel(self.db, ch, new_name)
        except Exception as e:
            messagebox.showerror("Rename failed", str(e))
            return
        self.refresh_all()

    def _rename_show(self, ch, show):
        new_name = simpledialog.askstring(
            "Rename show", f"New name for '{show['name']}':",
            initialvalue=show["name"], parent=self,
        )
        if not new_name:
            return
        new_name = new_name.strip()
        if not new_name or new_name == show["name"]:
            return
        try:
            library.rename_show(self.db, ch, show, new_name)
        except Exception as e:
            messagebox.showerror("Rename failed", str(e))
            return
        self.refresh_all()

    def _rename_bumper_group(self, ch, group):
        new_name = simpledialog.askstring(
            "Rename group", f"New name for '{group['name']}':",
            initialvalue=group["name"], parent=self,
        )
        if not new_name:
            return
        new_name = new_name.strip()
        if not new_name or new_name == group["name"]:
            return
        try:
            library.rename_bumper_group(self.db, ch, group, new_name)
        except Exception as e:
            messagebox.showerror("Rename failed", str(e))
            return
        self.refresh_all()

    def _rename_commercial_group(self, ch, group):
        new_name = simpledialog.askstring(
            "Rename group", f"New name for '{group['name']}':",
            initialvalue=group["name"], parent=self,
        )
        if not new_name:
            return
        new_name = new_name.strip()
        if not new_name or new_name == group["name"]:
            return
        try:
            library.rename_commercial_group(self.db, ch, group, new_name)
        except Exception as e:
            messagebox.showerror("Rename failed", str(e))
            return
        self.refresh_all()

    def _rename_block(self, ch, block):
        new_name = simpledialog.askstring(
            "Rename block", f"New name for '{block['name']}':",
            initialvalue=block["name"], parent=self,
        )
        if not new_name:
            return
        new_name = new_name.strip()
        if not new_name or new_name == block["name"]:
            return
        self.db.execute("UPDATE blocks SET name=? WHERE id=?", (new_name, block["id"]))
        self.refresh_all()

    # ------------------------------------------------------------------
    def clean_missing_clicked(self):
        missing = [r for r in self.db.query("SELECT id, path FROM media")
                   if not Path(r["path"]).exists()]
        if not missing:
            messagebox.showinfo("Clean missing files", "No missing files found.")
            return
        plural = "y" if len(missing) == 1 else "ies"
        if not messagebox.askyesno(
            "Clean missing files",
            f"Remove {len(missing)} media entr{plural}?\n\n"
            f"Shows/blocks/groups are left alone."
        ):
            return
        removed = library.clean_missing_files(self.db)
        self.refresh_all()
        self.status.config(text=f"Removed {removed} missing entr{'y' if removed == 1 else 'ies'}.")

    # ------------------------------------------------------------------
    def refresh_channels(self):
        old_label = None
        sel = self.channel_list.curselection()
        if sel:
            old_label = self.channel_list.get(sel[0])
        self._channels = self.db.get_channels()
        self.channel_list.delete(0, "end")
        restore_idx = None
        for i, c in enumerate(self._channels):
            prefix = f"[{c['number']}] " if c["number"] is not None else ""
            label = prefix + c["name"]
            self.channel_list.insert("end", label)
            if label == old_label:
                restore_idx = i
        if restore_idx is None and self._channels:
            restore_idx = 0
        if restore_idx is not None:
            self.channel_list.selection_set(restore_idx)
            self.on_channel_selected()

    def on_channel_selected(self):
        self.refresh_blocks()
        self.refresh_library()

    def refresh_blocks(self):
        old_sel = self.block_tree.selection()
        for item in self.block_tree.get_children():
            self.block_tree.delete(item)
        ch = self._selected_channel()
        if not ch:
            return
        for b in self.db.get_blocks(ch["id"]):
            shows = self.db.get_block_shows(b["id"])
            bgroups = self.db.get_block_bumper_groups(b["id"])
            cgroups = self.db.get_block_commercial_groups(b["id"])
            assign = (
                f"{len(shows)} show(s), {len(bgroups)} bumper group(s), "
                f"{len(cgroups)} commercial group(s)"
            )
            if b["shuffle_shows"]:
                assign += "  [shuffled]"
            self.block_tree.insert(
                "", "end", iid=str(b["id"]),
                values=(b["name"], pretty_days(b["days"]), b["start_time"],
                        f"{b['duration_minutes']} min", assign),
            )
        for s in old_sel:
            try:
                self.block_tree.selection_add(s)
            except tk.TclError:
                pass

    def refresh_library(self):
        open_iids = set()
        def collect(iid):
            if self.media_tree.item(iid, "open"):
                open_iids.add(iid)
            for child in self.media_tree.get_children(iid):
                collect(child)
        for item in self.media_tree.get_children():
            collect(item)
        old_sel = set(self.media_tree.selection())

        for item in self.media_tree.get_children():
            self.media_tree.delete(item)
        ch = self._selected_channel()
        if not ch:
            return

        # Shows
        shows_node = self.media_tree.insert("", "end", iid="shows-root",
                                            text="Shows", open=True)
        for s in self.db.get_shows_for_channel(ch["id"]):
            suffix = SHORT_SUFFIX.get(s["episode_order"], "")
            snode = self.media_tree.insert(
                shows_node, "end", iid=f"show-{s['id']}",
                text=f"{s['name']}{suffix}", open=False,
            )
            for m in self.db.media_for_show(s["id"]):
                self.media_tree.insert(
                    snode, "end",
                    values=(m["kind"], m["title"] or "", f"{m['duration']:.0f}s"),
                )

        # Bumper groups
        bumpers_node = self.media_tree.insert("", "end", iid="bumpers-root",
                                              text="Bumper groups", open=True)
        for g in self.db.get_bumper_groups(ch["id"]):
            gnode = self.media_tree.insert(
                bumpers_node, "end", iid=f"bg-{g['id']}",
                text=g["name"], open=False,
            )
            for m in self.db.media_for_bumper_group(g["id"]):
                self.media_tree.insert(
                    gnode, "end",
                    values=(m["kind"], m["title"] or "", f"{m['duration']:.0f}s"),
                )

        # Commercial groups
        comm_node = self.media_tree.insert("", "end", iid="commercials-root",
                                           text="Commercial groups", open=True)
        for g in self.db.get_commercial_groups(ch["id"]):
            gnode = self.media_tree.insert(
                comm_node, "end", iid=f"cg-{g['id']}",
                text=g["name"], open=False,
            )
            for m in self.db.media_for_commercial_group(g["id"]):
                self.media_tree.insert(
                    gnode, "end",
                    values=(m["kind"], m["title"] or "", f"{m['duration']:.0f}s"),
                )

        def restore(iid):
            if iid in open_iids:
                self.media_tree.item(iid, open=True)
            for child in self.media_tree.get_children(iid):
                restore(child)
        for item in self.media_tree.get_children():
            restore(item)
        for s in old_sel:
            try:
                self.media_tree.selection_add(s)
            except tk.TclError:
                pass

    def refresh_all(self):
        self.refresh_channels()
        self.refresh_blocks()
        self.refresh_library()

    # ------------------------------------------------------------------
    def new_channel(self):
        ChannelDialog(self, self.db)
        self.after(100, self.refresh_channels)

    def new_block(self):
        ch = self._selected_channel()
        if not ch:
            messagebox.showerror("No channel", "Select or create a channel first.")
            return
        BlockDialog(self, self.db, ch)
        self.after(100, self.refresh_blocks)

    def add_media(self):
        ch = self._selected_channel()
        MediaDialog(self, self.db, ch)
        self.after(200, self.refresh_all)

    def delete_channel(self):
        ch = self._selected_channel()
        if not ch:
            messagebox.showerror("No channel", "Select a channel first.")
            return
        folder = library.channel_root(ch["name"])
        if not messagebox.askyesno(
            "Delete channel",
            f"Delete channel '{ch['name']}' and its folder?\n\n{folder}\n\nCannot be undone."
        ):
            return
        self.db.delete_channel(ch["id"])
        if folder.exists():
            import shutil
            shutil.rmtree(folder, ignore_errors=True)
        self.refresh_all()

    def delete_block(self):
        block = self._selected_block()
        if not block:
            messagebox.showerror("No block", "Select a block first.")
            return
        if not messagebox.askyesno(
            "Delete block",
            f"Delete block '{block['name']}'?\n\n"
            f"Shows, bumper groups and commercial groups on the channel are NOT deleted."
        ):
            return
        self.db.delete_block(block["id"])
        self.refresh_blocks()

    def open_media_folder(self):
        open_path(MEDIA_ROOT)

    def watch_selected(self):
        ch = self._selected_channel()
        if not ch:
            messagebox.showerror("No channel", "Select a channel first.")
            return
        if self._launch_player(ch):
            self.hide_menu()
            self.status.config(
                text=f"Watching {ch['name']} — in the mpv window: Esc closes, "
                     f"Up/Down or digits change channel, M opens this menu"
            )

    # --- mpv session plumbing (mpv threads -> Tk thread via queue) -------
    def _tv_status(self, text):
        self._tv_queue.put(("status", text))

    def _tv_closed(self, player):
        self._tv_queue.put(("closed", player))

    def _tv_menu(self, player):
        self._tv_queue.put(("menu", player))

    def _poll_tv(self):
        last_status = None
        quit_now = False
        try:
            while True:
                kind, val = self._tv_queue.get_nowait()
                if kind == "status":
                    last_status = val
                elif kind == "closed":
                    if self._tv is val:
                        self._tv = None
                        last_status = "Channel closed."
                        # If the menu isn't showing, the player was the primary
                        # window — closing it means the user wants to quit.
                        if not self._menu_visible:
                            quit_now = True
                elif kind == "menu":
                    self.show_menu()
        except queue.Empty:
            pass
        if last_status is not None:
            try:
                self.status.config(text=last_status)
            except tk.TclError:
                pass
        if quit_now:
            try:
                self.destroy()
            except tk.TclError:
                pass
            return
        try:
            self.after(250, self._poll_tv)
        except tk.TclError:
            pass

    def _on_close(self):
        """Window X: hide the menu if the player is running, otherwise quit."""
        if self._tv is not None and self._tv.alive:
            self.hide_menu()
            return
        tv, self._tv = self._tv, None
        if tv is not None:
            try:
                tv.stop()
            except Exception:
                pass
        self.destroy()

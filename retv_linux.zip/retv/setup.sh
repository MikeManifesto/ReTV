#!/bin/sh
# setup.sh — portable installer for ArchiveTV
# Run with:  sh setup.sh
# No chmod required. Works on any POSIX sh.

set -e

# --- 1. Figure out where this script lives (portable, no bashisms) ---
DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
RUN_PY="$DIR/run.py"
ICON="$DIR/assets/icon.png"
DESKTOP_OUT="$DIR/ArchiveTV.desktop"

if [ ! -f "$RUN_PY" ]; then
    echo "ERROR: run.py not found next to this script ($RUN_PY)." >&2
    exit 1
fi

echo "==> ArchiveTV setup"
echo "    Folder: $DIR"

# --- 2. Detect distro / package manager ---
as_root() {
    if [ "$(id -u)" -eq 0 ]; then
        "$@"
    elif command -v sudo >/dev/null 2>&1; then
        sudo "$@"
    elif command -v doas >/dev/null 2>&1; then
        doas "$@"
    else
        echo "ERROR: need root (or sudo/doas) to install packages." >&2
        return 1
    fi
}

have() { command -v "$1" >/dev/null 2>&1; }

install_deps() {
    # We need: python3, and tkinter (python3-tk) in case the app uses tk.
    echo "==> Detecting package manager..."

    if have apt-get; then
        echo "    -> Debian/Ubuntu (apt)"
        as_root apt-get update
        as_root apt-get install -y python3 python3-tk python3-pil

    elif have dnf; then
        echo "    -> Fedora/RHEL (dnf)"
        as_root dnf install -y python3 python3-tkinter python3-pillow

    elif have yum; then
        echo "    -> CentOS/RHEL (yum)"
        as_root yum install -y python3 python3-tkinter python3-pillow

    elif have pacman; then
        echo "    -> Arch (pacman)"
        as_root pacman -Sy --needed --noconfirm python tk python-pillow

    elif have zypper; then
        echo "    -> openSUSE (zypper)"
        as_root zypper --non-interactive install python3 python3-tk python3-Pillow

    elif have apk; then
        echo "    -> Alpine (apk)"
        as_root apk add python3 py3-tkinter py3-pillow

    elif have xbps-install; then
        echo "    -> Void (xbps)"
        as_root xbps-install -Sy python3 python3-tkinter python3-Pillow

    elif have emerge; then
        echo "    -> Gentoo (emerge)"
        as_root emerge --ask=n dev-lang/python dev-python/pillow dev-tcltk/tk

    elif have nix-env; then
        echo "    -> NixOS (nix)"
        echo "    NOTE: on NixOS, add these to your config instead:"
        echo "          environment.systemPackages = [ pkgs.python3 pkgs.python3Packages.pillow pkgs.tk ];"
        echo "    Continuing without installing..."

    elif have flatpak; then
        echo "    -> No native package manager matched, but flatpak exists."
        echo "    You may need to install python3 + tkinter manually."

    else
        echo "    WARNING: unknown distro. Please install python3 + tkinter manually."
    fi
}

# --- 3. Verify python3 works ---
if ! have python3; then
    install_deps
fi

if ! have python3; then
    echo "ERROR: python3 still not available after install attempt." >&2
    exit 1
fi

echo "    python3: $(python3 --version 2>&1)"

# --- 4. Write the .desktop file with correct absolute paths ---
echo "==> Writing $DESKTOP_OUT"

# Escape any backslashes/dollars in paths so the heredoc is safe
esc() { printf '%s' "$1" | sed 's/[\\$`"]/\\&/g'; }
DIR_ESC=$(esc "$DIR")

cat > "$DESKTOP_OUT" <<EOF
[Desktop Entry]
Type=Application
Version=1.0
Name=ArchiveTV
GenericName=ATV
Comment=TV Emulator
Exec=python3 "$DIR_ESC/run.py"
Path=$DIR_ESC
Icon=$DIR_ESC/assets/icon.png
Terminal=false
Categories=Video;
Keywords=tv;Emulator;television;channel;channels;
StartupWMClass=ArchiveTV
EOF

chmod +x "$DESKTOP_OUT" 2>/dev/null || true
# (chmod above is best-effort; many desktops require the +x bit on
#  .desktop files that live on the Desktop, but not in the app menu.)

echo "==> Done."
echo
echo "Next steps:"
echo "  1. Copy or symlink this file to your Desktop:"
echo "       cp \"$DESKTOP_OUT\" ~/Desktop/"
echo "  2. If your desktop asks, right-click it and choose 'Allow launching'."
echo "  3. Double-click ArchiveTV to run."
echo
echo "(You can also just run: python3 \"$RUN_PY\")"

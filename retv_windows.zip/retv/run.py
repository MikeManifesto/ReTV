from tv_emulator import DB_PATH
from tv_emulator.db import DB
from tv_emulator.ui import App


def main():
    db = DB(DB_PATH)
    app = App(db)
    app.start_headless()
    app.mainloop()


if __name__ == "__main__":
    main()

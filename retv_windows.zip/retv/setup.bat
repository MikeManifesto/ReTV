@echo off
REM setup.bat — portable installer wrapper for ArchiveTV (Windows)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
echo.
pause

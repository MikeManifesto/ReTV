# setup.ps1 — portable installer for ArchiveTV (Windows)
# Run via:   powershell -ExecutionPolicy Bypass -File setup.ps1
#     or:    setup.bat  (double-click)

$ErrorActionPreference = 'Continue'

# --- 1. Where does this script live? ---
$Dir      = Split-Path -Parent $MyInvocation.MyCommand.Definition
$RunPy    = Join-Path $Dir 'run.py'
$IconPng  = Join-Path $Dir 'assets\icon.png'
$IconIco  = Join-Path $Dir 'assets\icon.ico'

if (-not (Test-Path $RunPy)) {
    Write-Host "ERROR: run.py not found next to this script ($RunPy)." -ForegroundColor Red
    exit 1
}

Write-Host "==> ArchiveTV setup"
Write-Host "    Folder: $Dir"
Write-Host ""

# --- 2. Helpers ---
function Get-PythonCommand {
    foreach ($cmd in @('py', 'python', 'python3')) {
        $c = Get-Command $cmd -ErrorAction SilentlyContinue
        if (-not $c) { continue }
        # Skip the Microsoft Store "app execution alias" stub
        if ($c.Source -like "$env:LOCALAPPDATA\Microsoft\WindowsApps\*") { continue }
        try {
            $out = & $cmd -c "print('ok')" 2>$null
            if ($LASTEXITCODE -eq 0 -and "$out".Trim() -eq 'ok') { return $cmd }
        } catch { }
    }
    return $null
}

function Refresh-Path {
    $m = [Environment]::GetEnvironmentVariable('Path','Machine')
    $u = [Environment]::GetEnvironmentVariable('Path','User')
    $env:Path = ($m, $u, $env:Path) -join ';'
}

# --- 3. Find / install Python ---
$PythonCmd = Get-PythonCommand

if (-not $PythonCmd) {
    Write-Host "==> Python not found. Trying to install..."
    $tried = $false

    if (Get-Command winget -ErrorAction SilentlyContinue) {
        Write-Host "    -> winget"
        $tried = $true
        winget install --id Python.Python.3.12 -e --source winget `
            --accept-package-agreements --accept-source-agreements | Out-Host
        Refresh-Path
        $PythonCmd = Get-PythonCommand
    }

    if (-not $PythonCmd -and (Get-Command choco -ErrorAction SilentlyContinue)) {
        Write-Host "    -> Chocolatey"
        $tried = $true
        choco install python -y | Out-Host
        Refresh-Path
        $PythonCmd = Get-PythonCommand
    }

    if (-not $PythonCmd -and (Get-Command scoop -ErrorAction SilentlyContinue)) {
        Write-Host "    -> Scoop"
        $tried = $true
        scoop install python | Out-Host
        Refresh-Path
        $PythonCmd = Get-PythonCommand
    }

    if (-not $PythonCmd) {
        Write-Host ""
        if (-not $tried) {
            Write-Host "ERROR: No package manager (winget/choco/scoop) found." -ForegroundColor Red
        } else {
            Write-Host "ERROR: Python still not available after install attempt." -ForegroundColor Red
        }
        Write-Host "       Install Python from https://www.python.org/downloads/ and re-run." -ForegroundColor Yellow
        exit 1
    }
}

Write-Host "    Python: $(& $PythonCmd --version)"

# Resolve real python.exe / pythonw.exe (pythonw = windowless launcher)
$PyExe = (& $PythonCmd -c "import sys; print(sys.executable)" 2>$null)
if (-not $PyExe) { $PyExe = (Get-Command $PythonCmd).Source }
$PyExe = "$PyExe".Trim()

$PyDir = Split-Path -Parent $PyExe
$PyW   = Join-Path $PyDir 'pythonw.exe'
if (-not (Test-Path $PyW)) { $PyW = $PyExe }

# --- 4. Make sure Pillow is installed ---
Write-Host "==> Checking Pillow..."
& $PyExe -c "import PIL" 2>$null
if ($LASTEXITCODE -ne 0) {
    Write-Host "==> Installing Pillow..."
    & $PyExe -m pip install --upgrade pip | Out-Host
    & $PyExe -m pip install Pillow       | Out-Host
    & $PyExe -c "import PIL" 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Host "WARNING: Pillow still not importable. The app may fail to load its icon." -ForegroundColor Yellow
    }
}

# --- 5. Convert PNG icon to ICO (Windows shortcuts need .ico) ---
if ((Test-Path $IconPng) -and -not (Test-Path $IconIco)) {
    Write-Host "==> Converting icon to .ico..."
    & $PyExe -c "from PIL import Image; im = Image.open(r'$IconPng').convert('RGBA'); im.save(r'$IconIco', sizes=[(16,16),(32,32),(48,48),(64,64),(128,128),(256,256)])" 2>$null
    if (-not (Test-Path $IconIco)) {
        Write-Host "    (conversion failed; shortcut will use a default icon)"
    }
}

# --- 6. Create Desktop shortcut (.lnk) ---
Write-Host "==> Creating Desktop shortcut..."
$Desktop       = [Environment]::GetFolderPath('Desktop')
$ShortcutPath  = Join-Path $Desktop 'ArchiveTV.lnk'

$WshShell = New-Object -ComObject WScript.Shell
$Shortcut = $WshShell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath        = $PyW
$Shortcut.Arguments         = "`"$RunPy`""
$Shortcut.WorkingDirectory  = $Dir
$Shortcut.Description       = 'ArchiveTV - TV Emulator'
if (Test-Path $IconIco)      { $Shortcut.IconLocation = "$IconIco,0" }
elseif (Test-Path $IconPng)  { $Shortcut.IconLocation = "$IconPng,0" }
$Shortcut.Save()

# --- 7. Also drop a launcher .bat next to run.py (fallback / portable use) ---
$Launcher = Join-Path $Dir 'ArchiveTV.bat'
$launcherText = @"
@echo off
start "" /D "$Dir" "$PyW" "$RunPy"
"@
Set-Content -Path $Launcher -Value $launcherText -Encoding ASCII

# --- 8. Done ---
Write-Host "==> Done."
Write-Host ""
Write-Host "Next steps:"
Write-Host "  1. A shortcut was placed on your Desktop: ArchiveTV.lnk"
Write-Host "  2. Double-click it to launch ArchiveTV."
Write-Host "  3. If SmartScreen warns, click 'More info' then 'Run anyway'."
Write-Host ""
Write-Host "(You can also run: $PythonCmd `"$RunPy`")"

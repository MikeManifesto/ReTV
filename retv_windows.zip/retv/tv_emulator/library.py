import json
import re
import shutil
import subprocess
import time
from pathlib import Path

from . import MEDIA_ROOT

SETTLE_SECONDS = 2.0
_pending_files = {}


def sanitize(name: str) -> str:
    name = re.sub(r'[<>:"/\\|?*]', "_", name).strip()
    return name or "untitled"


def get_duration(path) -> float:
    try:
        from mutagen import File as MFile
        f = MFile(str(path))
        if f is not None and f.info is not None:
            length = getattr(f.info, "length", None)
            if length:
                return float(length)
    except Exception:
        pass
    try:
        out = subprocess.check_output(
            ["ffprobe", "-v", "quiet", "-print_format", "json", "-show_format", str(path)],
            timeout=15,
        )
        return float(json.loads(out)["format"]["duration"])
    except Exception:
        return 0.0


# ---------------------------------------------------------------------------
# Folder helpers
# ---------------------------------------------------------------------------
def channel_root(channel_name) -> Path:
    return MEDIA_ROOT / "channels" / sanitize(channel_name)


def ensure_channel_tree(channel) -> Path:
    root = channel_root(channel["name"])
    (root / "shows").mkdir(parents=True, exist_ok=True)
    (root / "bumpers").mkdir(parents=True, exist_ok=True)
    (root / "commercials").mkdir(parents=True, exist_ok=True)
    return root


def ensure_show_tree(channel, show) -> Path:
    root = ensure_channel_tree(channel)
    sdir = root / "shows" / sanitize(show["name"])
    (sdir / "bumpers").mkdir(parents=True, exist_ok=True)
    return sdir


def ensure_bumper_group_dir(channel, group_name) -> Path:
    root = ensure_channel_tree(channel)
    d = root / "bumpers" / sanitize(group_name)
    d.mkdir(parents=True, exist_ok=True)
    return d


def ensure_commercial_group_dir(channel, group_name) -> Path:
    root = ensure_channel_tree(channel)
    d = root / "commercials" / sanitize(group_name)
    d.mkdir(parents=True, exist_ok=True)
    return d


# ---------------------------------------------------------------------------
# Import / scan
# ---------------------------------------------------------------------------
def _purge_pending():
    for p in list(_pending_files.keys()):
        if not Path(p).exists():
            del _pending_files[p]


def _maybe_import(db, channel, show, kind, file_path, existing_paths,
                  bumper_group_id=None, commercial_group_id=None):
    fp = Path(file_path)
    key = str(fp)
    if key in existing_paths:
        return False
    try:
        st = fp.stat()
    except OSError:
        return False
    sig = (st.st_size, st.st_mtime_ns)
    now = time.time()
    prev = _pending_files.get(key)
    if prev is not None and prev[0] == sig:
        if now - prev[1] >= SETTLE_SECONDS:
            db.add_media(
                channel_id=channel["id"],
                show_id=show["id"] if show else None,
                kind=kind,
                path=fp,
                title=fp.stem,
                duration=get_duration(fp),
                bumper_group_id=bumper_group_id,
                commercial_group_id=commercial_group_id,
            )
            del _pending_files[key]
            existing_paths.add(key)
            return True
        return False
    _pending_files[key] = (sig, now)
    return False


def _find_channel_by_folder(db, folder_name):
    for ch in db.get_channels():
        if sanitize(ch["name"]) == folder_name:
            return ch
    return None


def _find_show_by_folder(db, channel_id, folder_name):
    for s in db.get_shows_for_channel(channel_id):
        if sanitize(s["name"]) == folder_name:
            return s
    return None


def _find_bumper_group(db, channel_id, folder_name):
    for g in db.get_bumper_groups(channel_id):
        if sanitize(g["name"]) == folder_name:
            return g
    return None


def _find_commercial_group(db, channel_id, folder_name):
    for g in db.get_commercial_groups(channel_id):
        if sanitize(g["name"]) == folder_name:
            return g
    return None


def scan_and_import(db):
    _purge_pending()
    stats = {"channels": 0, "shows": 0, "bumper_groups": 0,
             "commercial_groups": 0, "files": 0}
    existing_paths = {r["path"] for r in db.query("SELECT path FROM media")}

    channels_root = MEDIA_ROOT / "channels"
    channels_root.mkdir(parents=True, exist_ok=True)

    for ch_dir in sorted(channels_root.iterdir()):
        if not ch_dir.is_dir():
            continue
        ch = _find_channel_by_folder(db, ch_dir.name)
        if ch is None:
            cid = db.add_channel(ch_dir.name)
            ch = db.get_channel(cid)
            stats["channels"] += 1
            ensure_channel_tree(ch)

        # Shows
        shows_dir = ch_dir / "shows"
        if shows_dir.is_dir():
            for s_dir in sorted(shows_dir.iterdir()):
                if not s_dir.is_dir():
                    continue
                s = _find_show_by_folder(db, ch["id"], s_dir.name)
                if s is None:
                    sid = db.add_show(ch["id"], s_dir.name)
                    s = db.query_one("SELECT * FROM shows WHERE id=?", (sid,))
                    stats["shows"] += 1
                bumpers_sub = s_dir / "bumpers"
                for f in sorted(s_dir.iterdir()):
                    if f.is_file() and _maybe_import(
                        db, ch, s, "episode", f, existing_paths
                    ):
                        stats["files"] += 1
                if bumpers_sub.is_dir():
                    for f in sorted(bumpers_sub.iterdir()):
                        if f.is_file() and _maybe_import(
                            db, ch, s, "show_bumper", f, existing_paths
                        ):
                            stats["files"] += 1

        # Bumper groups
        bumpers_dir = ch_dir / "bumpers"
        if bumpers_dir.is_dir():
            for g_dir in sorted(bumpers_dir.iterdir()):
                if not g_dir.is_dir():
                    continue
                g = _find_bumper_group(db, ch["id"], g_dir.name)
                if g is None:
                    gid = db.add_bumper_group(ch["id"], g_dir.name)
                    g = db.query_one("SELECT * FROM bumper_groups WHERE id=?", (gid,))
                    stats["bumper_groups"] += 1
                for f in sorted(g_dir.iterdir()):
                    if f.is_file() and _maybe_import(
                        db, ch, None, "bumper", f, existing_paths,
                        bumper_group_id=g["id"],
                    ):
                        stats["files"] += 1

        # Commercial groups
        commercials_dir = ch_dir / "commercials"
        if commercials_dir.is_dir():
            for g_dir in sorted(commercials_dir.iterdir()):
                if not g_dir.is_dir():
                    continue
                g = _find_commercial_group(db, ch["id"], g_dir.name)
                if g is None:
                    gid = db.add_commercial_group(ch["id"], g_dir.name)
                    g = db.query_one("SELECT * FROM commercial_groups WHERE id=?", (gid,))
                    stats["commercial_groups"] += 1
                for f in sorted(g_dir.iterdir()):
                    if f.is_file() and _maybe_import(
                        db, ch, None, "commercial", f, existing_paths,
                        commercial_group_id=g["id"],
                    ):
                        stats["files"] += 1

    return stats


def import_files(db, files, channel, kind, show=None,
                 bumper_group=None, commercial_group=None):
    root = ensure_channel_tree(channel)
    if kind == "episode" and show is not None:
        dest_dir = ensure_show_tree(channel, show)
        show_id = show["id"]
        b_id = c_id = None
    elif kind == "show_bumper" and show is not None:
        dest_dir = ensure_show_tree(channel, show) / "bumpers"
        show_id = show["id"]
        b_id = c_id = None
    elif kind == "bumper" and bumper_group is not None:
        dest_dir = ensure_bumper_group_dir(channel, bumper_group["name"])
        show_id = None
        b_id = bumper_group["id"]
        c_id = None
    elif kind == "commercial" and commercial_group is not None:
        dest_dir = ensure_commercial_group_dir(channel, commercial_group["name"])
        show_id = None
        b_id = None
        c_id = commercial_group["id"]
    else:
        raise ValueError(f"invalid import target: kind={kind}")

    dest_dir.mkdir(parents=True, exist_ok=True)
    count = 0
    for src in files:
        src = Path(src)
        if not src.is_file():
            continue
        dest = dest_dir / src.name
        n = 1
        while dest.exists():
            dest = dest_dir / f"{src.stem}_{n}{src.suffix}"
            n += 1
        shutil.copy2(src, dest)
        db.add_media(
            channel_id=channel["id"], show_id=show_id, kind=kind,
            path=dest, title=src.stem, duration=get_duration(dest),
            bumper_group_id=b_id, commercial_group_id=c_id,
        )
        _pending_files.pop(str(dest), None)
        count += 1
    return count


# ---------------------------------------------------------------------------
# Rename
# ---------------------------------------------------------------------------
def _rename_folder_and_paths(db, old_path, new_path, sql_update_name, sql_params):
    old_path = Path(old_path)
    new_path = Path(new_path)
    folder_renamed = False
    if old_path != new_path:
        if new_path.exists():
            raise ValueError(f"'{new_path.name}' already exists on disk.")
        if old_path.exists():
            old_path.rename(new_path)
            folder_renamed = True
    try:
        with db._lock:
            with db.conn:
                db.conn.execute(sql_update_name, sql_params)
                if folder_renamed:
                    db.conn.execute(
                        "UPDATE media SET path = ? || substr(path, ?) WHERE path LIKE ?",
                        (str(new_path), len(str(old_path)) + 1, str(old_path) + "/%"),
                    )
    except Exception:
        if folder_renamed:
            try:
                new_path.rename(old_path)
            except Exception:
                pass
        raise


def rename_channel(db, channel, new_name):
    _rename_folder_and_paths(
        db, channel_root(channel["name"]), channel_root(new_name),
        "UPDATE channels SET name=? WHERE id=?", (new_name, channel["id"]),
    )


def rename_show(db, channel, show, new_name):
    old_p = channel_root(channel["name"]) / "shows" / sanitize(show["name"])
    new_p = channel_root(channel["name"]) / "shows" / sanitize(new_name)
    _rename_folder_and_paths(
        db, old_p, new_p,
        "UPDATE shows SET name=? WHERE id=?", (new_name, show["id"]),
    )


def rename_bumper_group(db, channel, group, new_name):
    old_p = channel_root(channel["name"]) / "bumpers" / sanitize(group["name"])
    new_p = channel_root(channel["name"]) / "bumpers" / sanitize(new_name)
    _rename_folder_and_paths(
        db, old_p, new_p,
        "UPDATE bumper_groups SET name=? WHERE id=?", (new_name, group["id"]),
    )


def rename_commercial_group(db, channel, group, new_name):
    old_p = channel_root(channel["name"]) / "commercials" / sanitize(group["name"])
    new_p = channel_root(channel["name"]) / "commercials" / sanitize(new_name)
    _rename_folder_and_paths(
        db, old_p, new_p,
        "UPDATE commercial_groups SET name=? WHERE id=?", (new_name, group["id"]),
    )


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------
def clean_missing_files(db):
    removed = 0
    for row in db.query("SELECT id, path FROM media"):
        if not Path(row["path"]).exists():
            db.execute("DELETE FROM media WHERE id=?", (row["id"],))
            removed += 1
    return removed


# ---------------------------------------------------------------------------
# Legacy layout detection + migration
# ---------------------------------------------------------------------------
def has_old_layout():
    channels_root = MEDIA_ROOT / "channels"
    if not channels_root.is_dir():
        return False
    for ch_dir in channels_root.iterdir():
        if not ch_dir.is_dir():
            continue
        blocks_dir = ch_dir / "blocks"
        if blocks_dir.is_dir():
            try:
                if any(blocks_dir.iterdir()):
                    return True
            except OSError:
                pass
    return False


def migrate_old_layout(db):
    """Move files from the old block-scoped layout to the new channel-scoped layout."""
    channels_root = MEDIA_ROOT / "channels"
    if not channels_root.is_dir():
        return None
    stats = {"moved": 0, "errors": []}

    def _move(src, dst):
        if not src.exists():
            return
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists():
            base, ext = dst.stem, dst.suffix
            i = 1
            while dst.exists():
                dst = dst.parent / f"{base}_{i}{ext}"
                i += 1
        try:
            shutil.move(str(src), str(dst))
            stats["moved"] += 1
        except Exception as e:
            stats["errors"].append(f"{src}: {e}")

    for ch_dir in channels_root.iterdir():
        if not ch_dir.is_dir():
            continue
        shows_dir = ch_dir / "shows"
        bumpers_dir = ch_dir / "bumpers"
        commercials_dir = ch_dir / "commercials"

        if bumpers_dir.is_dir():
            loose = [f for f in bumpers_dir.iterdir() if f.is_file()]
            if loose:
                dest = bumpers_dir / "Channel bumpers"
                dest.mkdir(parents=True, exist_ok=True)
                for f in loose:
                    _move(f, dest / f.name)

        if commercials_dir.is_dir():
            loose = [f for f in commercials_dir.iterdir() if f.is_file()]
            if loose:
                dest = commercials_dir / "Default"
                dest.mkdir(parents=True, exist_ok=True)
                for f in loose:
                    _move(f, dest / f.name)

        blocks_dir = ch_dir / "blocks"
        if not blocks_dir.is_dir():
            continue

        for b_dir in list(blocks_dir.iterdir()):
            if not b_dir.is_dir():
                continue
            block_name = b_dir.name

            b_bumpers = b_dir / "bumpers"
            if b_bumpers.is_dir():
                dest = bumpers_dir / f"{block_name} bumpers"
                dest.mkdir(parents=True, exist_ok=True)
                for f in list(b_bumpers.iterdir()):
                    if f.is_file():
                        _move(f, dest / f.name)
                try:
                    b_bumpers.rmdir()
                except Exception:
                    pass

            b_shows = b_dir / "shows"
            if b_shows.is_dir():
                for s_dir in list(b_shows.iterdir()):
                    if not s_dir.is_dir():
                        continue
                    dest_show = shows_dir / s_dir.name
                    dest_show.mkdir(parents=True, exist_ok=True)
                    dest_bumpers = dest_show / "bumpers"
                    dest_bumpers.mkdir(parents=True, exist_ok=True)

                    old_eps = s_dir / "episodes"
                    if old_eps.is_dir():
                        for f in list(old_eps.iterdir()):
                            if f.is_file():
                                _move(f, dest_show / f.name)
                        try:
                            old_eps.rmdir()
                        except Exception:
                            pass

                    old_b = s_dir / "bumpers"
                    if old_b.is_dir():
                        for f in list(old_b.iterdir()):
                            if f.is_file():
                                _move(f, dest_bumpers / f.name)
                        try:
                            old_b.rmdir()
                        except Exception:
                            pass

                    for f in list(s_dir.iterdir()):
                        if f.is_file():
                            _move(f, dest_show / f.name)
                    try:
                        s_dir.rmdir()
                    except Exception:
                        pass
                try:
                    b_shows.rmdir()
                except Exception:
                    pass
            try:
                b_dir.rmdir()
            except Exception:
                pass
        try:
            blocks_dir.rmdir()
        except Exception:
            pass

    db.execute("DELETE FROM media")
    return stats


# ---------------------------------------------------------------------------
# Channel logos  (<channel folder>/logo.png|jpg|jpeg|webp|bmp|gif)
# ---------------------------------------------------------------------------
LOGO_EXTS = (".png", ".jpg", ".jpeg", ".webp", ".bmp", ".gif")


def _logo_files(channel):
    root = channel_root(channel["name"])
    try:
        return [f for f in root.iterdir()
                if f.is_file() and f.stem.lower() == "logo" and f.suffix.lower() in LOGO_EXTS]
    except OSError:
        return []


def find_channel_logo(channel):
    files = _logo_files(channel)
    return files[0] if files else None


def clear_channel_logo(channel):
    for f in _logo_files(channel):
        try:
            f.unlink()
        except OSError:
            pass


def set_channel_logo(channel, src):
    src = Path(src)
    if src.suffix.lower() not in LOGO_EXTS:
        raise ValueError("Logo must be an image (png, jpg, webp, bmp, gif).")
    root = ensure_channel_tree(channel)
    clear_channel_logo(channel)
    shutil.copy2(src, root / f"logo{src.suffix.lower()}")

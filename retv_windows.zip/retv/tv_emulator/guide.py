"""
Data model + navigation for the interactive on-screen TV guide.

The model is built once when the guide opens (one row of contiguous "cells"
per channel) and is then navigated purely in memory:

    Up/Down      move between channels
    Left/Right   move between programs on the selected channel
    [ / ]        jump -12 / +12 hours
    PgUp/PgDn    move a page of channels
    Enter        tune the highlighted channel

Rows contain, in order of precision:
  * "program" cells - the real, frozen playlist of the block airing right now
  * "block" cells   - blocks scheduled later (their playlist doesn't exist
                      yet, so only the block name and its shows are known)
  * "gap" cells     - "No Information" filler so every moment has a cell
"""
from dataclasses import dataclass
from datetime import datetime

from . import scheduler

SLOT = 1800                 # grid column = 30 minutes
SPAN_SLOTS = 3              # visible columns (1.5 hours, like the reference)
HORIZON = 48 * 3600         # how far ahead the guide reaches


def floor_slot(ts):
    return (ts // SLOT) * SLOT


@dataclass
class Cell:
    start: float
    end: float
    title: str
    subtitle: str = ""
    kind: str = "program"       # program | block | gap
    block_name: str = ""


def _gap(start, end):
    return Cell(start, end, "No Information", "", "gap")


def _row_cells(db, ch, now_ts, lo, hi):
    entries = []
    airing_key = None
    try:
        airing = scheduler.now_airing(db, ch["id"], datetime.fromtimestamp(now_ts))
    except Exception as e:  # a broken channel must not break the whole guide
        print(f"Guide: schedule error on {ch['name']}: {e}")
        airing = None

    if airing is not None and not airing.empty:
        block_end = airing.block_end.timestamp()
        progs, _ = scheduler.programs_for(db, airing)
        for p in progs:
            s = airing.anchor_time + p.start
            e = min(airing.anchor_time + p.end, block_end)
            if e <= s:
                continue
            entries.append(Cell(s, e, p.show_name or "Station Break",
                                p.title or "", "program", airing.block["name"]))
        airing_key = (airing.block["id"], airing.anchor_time)

    show_names = {}
    for block, s, e in scheduler.block_occurrences(db, ch["id"], lo, hi):
        if airing_key and block["id"] == airing_key[0] and abs(s - airing_key[1]) < 1.0:
            continue  # already covered by the real playlist
        if block["id"] not in show_names:
            show_names[block["id"]] = [x["name"] for x in db.get_block_shows(block["id"])]
        names = show_names[block["id"]]
        sub = ", ".join(names[:3]) + ("…" if len(names) > 3 else "")
        entries.append(Cell(s, e, block["name"], sub, "block", block["name"]))

    # Later-starting entries win where they overlap (same rule as current_block)
    entries.sort(key=lambda c: (c.start, 1 if c.kind == "program" else 0))
    merged = []
    for c in entries:
        while merged and c.start < merged[-1].end:
            last = merged[-1]
            if last.start >= c.start:
                merged.pop()
                continue
            last.end = c.start
            break
        merged.append(c)

    # Fill holes so every instant between lo and hi has a cell
    out = []
    cursor = lo
    for c in merged:
        if c.end <= lo or c.start >= hi:
            continue
        gap = c.start - cursor
        if 0 < gap <= 1.0:
            c.start = cursor
        elif gap > 1.0:
            out.append(_gap(cursor, c.start))
        out.append(c)
        cursor = c.end
    if hi - cursor > 1.0:
        out.append(_gap(cursor, hi))
    return out


def describe(ch, cell):
    """One or two sentences for the guide header."""
    if cell.kind == "gap":
        return "No program information is available for this time."
    if cell.kind == "block":
        txt = f"Scheduled block on {ch['name']}."
        if cell.subtitle:
            txt += f" Features {cell.subtitle}."
        return txt
    if cell.title == "Station Break":
        return f"Commercials and station breaks on {ch['name']}."
    mins = max(1, round((cell.end - cell.start) / 60))
    txt = "Series."
    if cell.subtitle and cell.subtitle.lower() != cell.title.lower():
        txt += f" {cell.subtitle}."
    txt += f" {mins} min."
    if cell.block_name:
        txt += f" Part of the {cell.block_name} block on {ch['name']}."
    return txt


class GuideModel:
    def __init__(self, channels, rows, live_id, now_ts):
        self.channels = channels        # [{"id", "number", "name"}]
        self.rows = rows                # [[Cell, ...], ...] (parallel to channels)
        self.live_id = live_id          # channel currently being watched
        self.now_ts = now_ts
        self.lo = floor_slot(now_ts)
        self.hi = self.lo + HORIZON
        self.span = SPAN_SLOTS * SLOT
        self.t0 = self.lo               # left edge of the visible window
        self.sel_ts = now_ts            # selected moment (cell containing it is highlighted)
        self.sel_row = 0
        for i, c in enumerate(channels):
            if c["id"] == live_id:
                self.sel_row = i
                break
        self.row_off = 0                # first visible row
        self.n_vis = 8                  # updated by the renderer
        self.last_draw = 0.0

    # ------------------------------------------------------------------
    @classmethod
    def build(cls, db, live_id, now_ts):
        lo = floor_slot(now_ts)
        hi = lo + HORIZON
        channels, rows = [], []
        for ch in db.get_channels():
            channels.append({"id": ch["id"], "number": ch["number"], "name": ch["name"]})
            rows.append(_row_cells(db, ch, now_ts, lo, hi))
        return cls(channels, rows, live_id, now_ts)

    # ------------------------------------------------------------------
    def cell_at(self, row, ts):
        cells = self.rows[row]
        for c in cells:
            if c.start <= ts < c.end:
                return c
        return cells[-1] if ts >= self.hi else cells[0]

    def selected_cell(self):
        return self.cell_at(self.sel_row, self.sel_ts)

    def selected_channel(self):
        return self.channels[self.sel_row]

    # ------------------------------------------------------------------
    def move_row(self, delta, wrap=True):
        n = len(self.channels)
        if not n:
            return
        new = self.sel_row + delta
        self.sel_row = new % n if wrap else max(0, min(n - 1, new))

    def move_time(self, direction):
        if not self.channels:
            return
        cell = self.selected_cell()
        if direction > 0:
            if cell.end >= self.hi - 1:
                return
            self.sel_ts = cell.end
        else:
            if cell.start <= self.lo:
                return
            self.sel_ts = cell.start - 0.001
        self._scroll()

    def jump_hours(self, hours):
        self.sel_ts = max(self.lo, min(self.hi - 1, self.sel_ts + hours * 3600))
        self.t0 = floor_slot(self.sel_ts)
        self._scroll()

    def select_channel_number(self, number):
        for i, c in enumerate(self.channels):
            if c["number"] == number:
                self.sel_row = i
                return True
        return False

    def _scroll(self):
        cell = self.selected_cell()
        if self.sel_ts < self.t0:
            self.t0 = floor_slot(max(cell.start, self.lo))
        elif self.sel_ts >= self.t0 + self.span:
            self.t0 = floor_slot(self.sel_ts)
        self.t0 = max(self.lo, min(self.t0, self.hi - self.span))

from pathlib import Path
import os

TV_ROOT = Path(os.environ.get("TV_EMULATOR_HOME", Path.home() / ".tv_emulator"))
MEDIA_ROOT = TV_ROOT / "media"
DB_PATH = TV_ROOT / "tv.db"

TV_ROOT.mkdir(parents=True, exist_ok=True)
MEDIA_ROOT.mkdir(parents=True, exist_ok=True)

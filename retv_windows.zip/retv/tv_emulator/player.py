import threading
import time
from pathlib import Path
from datetime import datetime

from . import library, scheduler
from .infobar import InfoBar


def _fmt(sec):
    sec = int(max(0, sec))
    m, s = divmod(sec, 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


class ChannelPlayer:
    """
    Live-TV style player.

    The wall clock is the single source of truth: the channel's frozen
    playlist (see scheduler.Airing) maps "now" to (item, offset).  Leaving
    and coming back simply re-asks that question, so you always land exactly
    where the broadcast is.  While watching, the player re-syncs to the clock
    at item boundaries, on block changes, and whenever playback drifts.
    """

    POLL = 0.5             # monitor loop period
    SCHEDULE_CHECK = 5.0   # how often to re-validate schedule edits
    SNAP = 1.0             # offsets below this start the item from 0
    MAX_DRIFT = 2.5        # re-seek if playback is this far from the clock
    START_GRACE = 2.0      # ignore drift right after loading an item
    SEEK_COOLDOWN = 3.0
    LOAD_TIMEOUT = 6.0
    MAX_RETRIES = 2        # reload attempts for an item that dies early

    def __init__(self, db, channel_id, status_cb, on_close=None, on_menu=None):
        """
        Opens a standalone, fullscreen mpv window (no Tk window involved).
        Keys inside the mpv window:
          Esc close · Up/Down next/prev channel · digits (+Enter) jump to a
          channel number · f fullscreen · g guide · i / Space what's on · m menu
        `on_close(player)` is called once when the mpv window goes away
        (Esc, or the window's own close button).
        `on_menu(player)` is called when the user presses M inside mpv.
        """
        import mpv

        self._mpv = mpv
        self.db = db
        self.channel_id = channel_id
        self.status_cb = status_cb
        self.on_close = on_close
        self.on_menu = on_menu
        self._stop = threading.Event()
        self._thread = None
        self._switch = threading.Event()
        self._closed_notified = False
        self._num_buf = ""
        self._num_timer = None
        self._num_lock = threading.Lock()
        self._last_status = ""
        self._cur = None            # (airing, item idx) currently on air
        self._force_bar = True      # show the banner on the next item

        ch = db.get_channel(channel_id)
        self.player = mpv.MPV(
            input_default_bindings=False,
            input_vo_keyboard=True,
            osc=False,
            really_quiet=True,
            keep_open=False,
            idle=True,
            force_window=True,
            fullscreen=True,
            title=f"TV — {self._label(ch)}" if ch else "TV",
        )
        self.player.volume = 80
        self.infobar = InfoBar(self.player)
        self._register_keys()
        try:
            self.player.event_callback("shutdown")(self._on_shutdown_event)
        except Exception:
            pass

    @property
    def alive(self):
        return not self._stop.is_set()

    # ------------------------------------------------------------------
    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        try:
            self.db.set_setting("last_channel", str(self.channel_id))
        except Exception:
            pass
        ch = self.db.get_channel(self.channel_id)
        if ch and not self.infobar.available:
            self.osd(self._label(ch), 3000)

    def stop(self):
        self._stop.set()
        try:
            self.infobar.hide()
        except Exception:
            pass
        self._switch.set()
        self._cancel_number()
        t = self._thread
        if t and t.is_alive() and t is not threading.current_thread():
            t.join(timeout=1.5)
        try:
            self.player.terminate()
        except Exception:
            pass
        self._notify_closed()

    def _notify_closed(self):
        if self._closed_notified:
            return
        self._closed_notified = True
        if self.on_close:
            try:
                self.on_close(self)
            except Exception:
                pass

    def _on_shutdown_event(self, *_a):
        # the mpv window was closed (e.g. its close button)
        self._stop.set()
        self._switch.set()
        self._notify_closed()
        self._close_async()  # free libmpv properly (off the event thread)

    def _close_async(self):
        # never terminate mpv from its own event thread
        threading.Thread(target=self.stop, daemon=True).start()

    # ------------------------------------------------------------------
    # Keyboard (runs on mpv's event thread)
    # ------------------------------------------------------------------
    def _register_keys(self):
        def bind(key, fn):
            try:
                self.player.on_key_press(key)(fn)
            except Exception:
                pass

        bind("ESC", self._close_async)
        bind("Alt+F4", self._close_async)

        # Up/Down change channel while playing; inside the guide they move
        # the highlighted row.
        bind("UP", lambda: (
            self._guide_key(lambda m: m.move_row(-1))
            if self.infobar.guide_open else self._step(+1)
        ))
        bind("DOWN", lambda: (
            self._guide_key(lambda m: m.move_row(+1))
            if self.infobar.guide_open else self._step(-1)
        ))
        bind("LEFT",  lambda: self._guide_key(lambda m: m.move_time(-1)))
        bind("RIGHT", lambda: self._guide_key(lambda m: m.move_time(+1)))
        bind("PGUP", lambda: (
            self._guide_key(lambda m: m.move_row(-m.n_vis))
            if self.infobar.guide_open else self._step(+1)
        ))
        bind("PGDWN", lambda: (
            self._guide_key(lambda m: m.move_row(+m.n_vis))
            if self.infobar.guide_open else self._step(-1)
        ))
        bind("[", lambda: self._guide_key(lambda m: m.jump_hours(-12)))
        bind("]", lambda: self._guide_key(lambda m: m.jump_hours(+12)))

        # Enter commits a typed channel number normally; inside the guide it
        # tunes the highlighted channel.
        def on_enter():
            if self.infobar.guide_open:
                self._guide_tune_selected()
            else:
                self._commit_number()
        bind("ENTER", on_enter)
        bind("KP_ENTER", on_enter)

        bind("BS", self._backspace)
        bind("f", self._toggle_fullscreen)
        bind("i", self._show_bar_now)
        bind("SPACE", self._show_bar_now)
        bind("KP_SPACE", self._show_bar_now)
        bind("g", self._toggle_guide)
        bind("G", self._toggle_guide)
        bind("m", self._open_menu)
        bind("M", self._open_menu)
        for d in "0123456789":
            bind(d, lambda d=d: self._type_digit(d))
            bind(f"KP{d}", lambda d=d: self._type_digit(d))

    def _toggle_fullscreen(self):
        try:
            self.player.fullscreen = not self.player.fullscreen
        except Exception:
            pass

    def _open_menu(self):
        cb = self.on_menu
        if cb:
            try:
                cb(self)
            except Exception:
                import traceback
                traceback.print_exc()

    def _toggle_guide(self):
        if self.infobar.visible:
            self.infobar.hide()
            return

        # Import here (not at module scope) so a broken guide module can
        # never stop the player from starting.
        from .guide import GuideModel
        try:
            model = GuideModel.build(self.db, self.channel_id, time.time())
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.osd(f"Guide error: {e}", 4000)
            return

        if not self.infobar.show_guide(model):
            self.osd("Guide unavailable (Pillow missing?)", 3000)

    def _guide_key(self, fn):
        """Run fn(model) if the guide is open, then redraw. Safe to call
        from mpv's event thread — exceptions become an OSD instead of
        vanishing silently."""
        if not self.infobar.guide_open:
            return
        model = self.infobar.guide_model
        if model is None:
            return
        try:
            fn(model)
            self.infobar.redraw_guide()
        except Exception as e:
            import traceback
            traceback.print_exc()
            self.osd(f"Guide error: {e}", 3000)

    def _guide_tune_selected(self):
        if not self.infobar.guide_open:
            return
        model = self.infobar.guide_model
        if model is None or not model.channels:
            return
        ch = model.selected_channel()
        row = self.db.get_channel(ch["id"])
        if row is None:
            return
        self.infobar.hide()
        if row["id"] == self.channel_id:
            self.osd(self._label(row), 3000)
        else:
            self.tune(row)

    @staticmethod
    def _label(ch):
        if ch is None:
            return ""
        return f"{ch['number']}  {ch['name']}" if ch["number"] is not None else ch["name"]

    def tune(self, ch):
        """Switch channel (thread-safe)."""
        self._cancel_number()
        self.channel_id = ch["id"]
        try:
            self.db.set_setting("last_channel", str(ch["id"]))
        except Exception:
            pass
        self._cur = None
        self._force_bar = True
        self.infobar.hide()
        self._switch.set()
        try:
            self.player.title = f"TV — {self._label(ch)}"
        except Exception:
            pass
        if not self.infobar.available:
            self.osd(self._label(ch), 3000)

    def _step(self, delta):
        chans = list(self.db.get_channels())
        if not chans:
            return
        ids = [c["id"] for c in chans]
        try:
            i = ids.index(self.channel_id)
        except ValueError:
            i = -1 if delta > 0 else 0
        self.tune(chans[(i + delta) % len(chans)])

    def _type_digit(self, d):
        with self._num_lock:
            if len(self._num_buf) >= 4:
                self._num_buf = ""
            self._num_buf += d
            self._restart_number_timer()

    def _backspace(self):
        with self._num_lock:
            self._num_buf = self._num_buf[:-1]
            self._restart_number_timer()

    def _restart_number_timer(self):  # call with _num_lock held
        if self._num_timer is not None:
            self._num_timer.cancel()
            self._num_timer = None
        if not self._num_buf:
            self.osd(" ", 100)
            return
        self.osd(f"Channel {self._num_buf}_", 2000)
        self._num_timer = threading.Timer(1.5, self._commit_number)
        self._num_timer.daemon = True
        self._num_timer.start()

    def _cancel_number(self):
        with self._num_lock:
            self._num_buf = ""
            if self._num_timer is not None:
                self._num_timer.cancel()
                self._num_timer = None

    def _commit_number(self):
        with self._num_lock:
            buf = self._num_buf
            self._num_buf = ""
            if self._num_timer is not None:
                self._num_timer.cancel()
                self._num_timer = None
        if not buf or self._stop.is_set():
            return
        n = int(buf)
        for c in self.db.get_channels():
            if c["number"] == n:
                if c["id"] == self.channel_id:
                    self.osd(self._label(c), 3000)
                else:
                    self.tune(c)
                return
        self.osd(f"No channel {n}", 2500)

    # ------------------------------------------------------------------
    def _wait(self, timeout):
        """Sleep up to `timeout`, waking early on stop or channel switch.
        Returns True if the player is being stopped."""
        end = time.time() + max(0.0, timeout)
        while not self._stop.is_set() and not self._switch.is_set():
            rem = end - time.time()
            if rem <= 0:
                break
            self._stop.wait(min(rem, 0.1))
        return self._stop.is_set()

    def set_channel(self, channel_id):
        """Switch to another channel while running (thread-safe)."""
        self.channel_id = channel_id
        self._switch.set()

    def osd(self, text, ms=2500):
        """Show text on top of the video (mpv's own on-screen display)."""
        try:
            self.player.show_text(text, str(int(ms)))
        except Exception:
            pass

    def _blank(self):
        """Stop whatever is playing (off air / no media) so old video doesn't linger."""
        self.infobar.hide()
        self._cur = None
        try:
            if not self._idle():
                self.player.stop()
        except Exception:
            pass

    # --- info banner ---------------------------------------------------
    def _build_info(self, airing, idx, now=None):
        now = time.time() if now is None else now
        progs, item_prog = scheduler.programs_for(self.db, airing)
        if not progs or idx >= len(item_prog):
            return None
        pi = item_prog[idx]
        prog = progs[pi]
        nxt = progs[pi + 1] if pi + 1 < len(progs) else None
        ch = self.db.get_channel(self.channel_id)
        if ch is None:
            return None
        logo = library.find_channel_logo(ch)
        return dict(
            channel_number=ch["number"],
            channel_name=ch["name"],
            logo=str(logo) if logo else None,
            title=prog.show_name or "Station Break",
            subtitle=prog.title,
            start_ts=airing.anchor_time + prog.start,
            end_ts=airing.anchor_time + prog.end,
            now_ts=now,
            next_title=((nxt.show_name or "Station Break") if nxt else ""),
            block_name=airing.block["name"],
        )

    def _show_bar(self, airing, idx, seconds=8.0):
        info = self._build_info(airing, idx)
        if info is None:
            return
        if not self.infobar.show(info, seconds):
            # no Pillow / overlay support: plain text fallback
            head = self._label(self.db.get_channel(self.channel_id))
            t0, t1 = info["start_ts"], info["end_ts"]
            from .infobar import clock
            self.osd(f"{head}\n{info['title']}\n{clock(t0)} - {clock(t1)}", seconds * 1000)

    def _show_bar_now(self):
        if self.infobar.visible:
            self.infobar.hide()
            return

        cur = self._cur
        if cur is None:
            self.osd(self._last_status or "", 4000)
            return
        self._show_bar(cur[0], cur[1], 8.0)

    def _status(self, text, important=False):
        self._last_status = text
        try:
            self.status_cb(text)
        except Exception:
            pass
        if important:
            self.osd(text, 4000)

    def _idle(self):
        try:
            return bool(self.player.idle_active)
        except Exception:
            try:
                return self.player.path is None
            except Exception:
                return False

    # ------------------------------------------------------------------
    def _run(self):
        fails = {}
        last_token = None
        while not self._stop.is_set():
            self._switch.clear()
            channel_id = self.channel_id
            try:
                airing = scheduler.now_airing(self.db, channel_id)
            except Exception as e:
                self._status(f"Schedule error: {e}", True)
                if self._wait(3):
                    break
                continue

            if airing is None:
                self._blank()
                self._status("Off air — nothing scheduled", True)
                if self._wait(3):
                    break
                continue
            if airing.empty:
                self._blank()
                self._status(f"Block '{airing.block['name']}' has no playable media yet", True)
                if self._wait(3):
                    break
                continue

            if airing.token != last_token:
                fails.clear()
                last_token = airing.token

            spot = airing.locate(time.time())
            if spot is None:  # block just ended; re-resolve
                if self._wait(0.25):
                    break
                continue

            try:
                self._play_spot(airing, spot, fails)
            except Exception as e:
                if self._stop.is_set():
                    break
                self._status(f"Playback error: {e}", True)
                if self._wait(1.0):
                    break

    # ------------------------------------------------------------------
    def _play_spot(self, airing, spot, fails):
        if self._switch.is_set():
            return
        key = (airing.token, spot.idx)
        rows = self.db.get_media_by_ids([spot.media_id])
        media = rows.get(spot.media_id)

        if spot.remaining < 1.0:
            self._wait(spot.remaining)
            return

        path = Path(media["path"]) if media else None
        if path is None or not path.exists():
            self._status("Item unavailable — waiting for the next one…", True)
            self._wait(min(spot.remaining, 5.0))
            return
        if fails.get(key, 0) > self.MAX_RETRIES:
            self._status("Item failed to play — waiting for the next one…", True)
            self._wait(min(spot.remaining, 5.0))
            return

        offset = spot.offset if spot.offset >= self.SNAP else 0.0

        # Set the start position BEFORE loading so it deterministically
        # applies to this file.
        try:
            self.player.command("set", "start", f"{offset:.3f}")
        except Exception:
            pass
        self.player.play(str(path))

        t0 = time.time()
        while self._idle():
            if self._stop.is_set() or self._switch.is_set():
                return
            if time.time() - t0 > self.LOAD_TIMEOUT:
                fails[key] = fails.get(key, 0) + 1
                raise RuntimeError(f"could not load {path.name}")
            self._wait(0.05)

        self.db.mark_played(spot.media_id)

        self._cur = (airing, spot.idx)
        if self._force_bar:
            self._force_bar = False
            self._show_bar(airing, spot.idx, 8.0)

        title = media["title"] or path.name
        nxt_title = ""
        nid = airing.next_media_id(spot.idx)
        if nid is not None:
            nrow = self.db.get_media_by_ids([nid]).get(nid)
            if nrow:
                nxt_title = nrow["title"] or Path(nrow["path"]).name

        started = time.time()
        last_seek = 0.0
        last_sched = started
        last_status = 0.0

        while not self._stop.is_set():
            if self._switch.is_set():
                return
            now = time.time()
            cur = airing.locate(now)
            if cur is None or cur.idx != spot.idx:
                return  # block over, or the clock moved to another item

            if self._idle():
                if cur.remaining > 3.0:
                    # ended far too early -> playback failure, maybe retry
                    fails[key] = fails.get(key, 0) + 1
                else:
                    self._wait(cur.remaining)  # natural end: wait for boundary
                return

            if now - last_sched >= self.SCHEDULE_CHECK:
                last_sched = now
                fresh = scheduler.now_airing(self.db, self.channel_id)
                if fresh is None or fresh.token != airing.token:
                    return

            if now - started > self.START_GRACE and now - last_seek > self.SEEK_COOLDOWN:
                try:
                    tp = self.player.time_pos
                except Exception:
                    tp = None
                if tp is not None and abs(tp - cur.offset) > self.MAX_DRIFT:
                    try:
                        self.player.seek(cur.offset, reference="absolute")
                        last_seek = now
                    except Exception:
                        pass

            if now - last_status >= 1.0:
                last_status = now
                msg = (f"{airing.block['name']} — {title}   "
                       f"{_fmt(cur.offset)} / {_fmt(cur.duration)}")
                if nxt_title:
                    msg += f"   ·   Up next: {nxt_title}"
                self._status(msg)
                if self.infobar.visible:
                    self.infobar.refresh(self._build_info(airing, cur.idx, now))

            if self._wait(self.POLL):
                return

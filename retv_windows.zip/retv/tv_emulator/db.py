import sqlite3
import threading
import time

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS channels (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    number INTEGER,
    bumper_order TEXT NOT NULL DEFAULT 'rotation',
    commercial_order TEXT NOT NULL DEFAULT 'rotation'
);

CREATE TABLE IF NOT EXISTS blocks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    days TEXT NOT NULL DEFAULT '0,1,2,3,4,5,6',
    start_time TEXT NOT NULL DEFAULT '00:00',
    duration_minutes INTEGER NOT NULL DEFAULT 60,
    shuffle_shows INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS shows (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id INTEGER REFERENCES channels(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    episode_order TEXT NOT NULL DEFAULT 'rotation'
);

CREATE TABLE IF NOT EXISTS bumper_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    UNIQUE(channel_id, name)
);

CREATE TABLE IF NOT EXISTS commercial_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id INTEGER NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    UNIQUE(channel_id, name)
);

CREATE TABLE IF NOT EXISTS block_shows (
    block_id INTEGER NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
    show_id INTEGER NOT NULL REFERENCES shows(id) ON DELETE CASCADE,
    PRIMARY KEY(block_id, show_id)
);

CREATE TABLE IF NOT EXISTS block_bumper_groups (
    block_id INTEGER NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
    bumper_group_id INTEGER NOT NULL REFERENCES bumper_groups(id) ON DELETE CASCADE,
    PRIMARY KEY(block_id, bumper_group_id)
);

CREATE TABLE IF NOT EXISTS block_commercial_groups (
    block_id INTEGER NOT NULL REFERENCES blocks(id) ON DELETE CASCADE,
    commercial_group_id INTEGER NOT NULL REFERENCES commercial_groups(id) ON DELETE CASCADE,
    PRIMARY KEY(block_id, commercial_group_id)
);

CREATE TABLE IF NOT EXISTS media (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    channel_id INTEGER REFERENCES channels(id) ON DELETE CASCADE,
    show_id INTEGER REFERENCES shows(id) ON DELETE CASCADE,
    bumper_group_id INTEGER REFERENCES bumper_groups(id) ON DELETE CASCADE,
    commercial_group_id INTEGER REFERENCES commercial_groups(id) ON DELETE CASCADE,
    kind TEXT NOT NULL,
    path TEXT NOT NULL UNIQUE,
    title TEXT,
    duration REAL NOT NULL DEFAULT 0,
    last_played REAL NOT NULL DEFAULT 0,
    play_count INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS broadcast_anchor (
    channel_id INTEGER PRIMARY KEY REFERENCES channels(id) ON DELETE CASCADE,
    block_id INTEGER NOT NULL,
    anchor_time REAL NOT NULL,
    seed INTEGER NOT NULL,
    playlist TEXT
);

CREATE TABLE IF NOT EXISTS channel_position (
    channel_id INTEGER PRIMARY KEY REFERENCES channels(id) ON DELETE CASCADE,
    media_id INTEGER,
    position_seconds REAL NOT NULL DEFAULT 0,
    updated_at REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

MIGRATIONS = [
    ("channels", "bumper_order", "TEXT NOT NULL DEFAULT 'rotation'"),
    ("channels", "commercial_order", "TEXT NOT NULL DEFAULT 'rotation'"),
    ("shows", "episode_order", "TEXT NOT NULL DEFAULT 'rotation'"),
    ("shows", "channel_id", "INTEGER"),
    ("media", "bumper_group_id", "INTEGER"),
    ("media", "commercial_group_id", "INTEGER"),
    ("broadcast_anchor", "playlist", "TEXT"),
]


class DB:
    def __init__(self, path):
        self._lock = threading.RLock()
        self.conn = sqlite3.connect(str(path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self.conn.executescript(SCHEMA)
        self._apply_migrations()
        self.conn.commit()

    # ------------------------------------------------------------------
    def _apply_migrations(self):
        for table, column, decl in MIGRATIONS:
            cols = {r[1] for r in self.conn.execute(f"PRAGMA table_info({table})")}
            if column not in cols:
                self.conn.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")

        show_cols = {r[1] for r in self.conn.execute("PRAGMA table_info(shows)")}
        if "block_id" in show_cols:
            self._migrate_shows_table()

        media_cols = {r[1] for r in self.conn.execute("PRAGMA table_info(media)")}
        if "block_id" in media_cols:
            self._migrate_media_to_groups()

    def _migrate_shows_table(self):
        self.conn.execute("PRAGMA foreign_keys = OFF")
        old_shows = self.conn.execute("""
            SELECT s.id, s.block_id, s.name,
                   COALESCE(s.episode_order, 'rotation') AS eo,
                   b.channel_id
            FROM shows s
            LEFT JOIN blocks b ON b.id = s.block_id
        """).fetchall()
        self.conn.execute("DROP TABLE shows")
        self.conn.execute("""
            CREATE TABLE shows (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                channel_id INTEGER REFERENCES channels(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                episode_order TEXT NOT NULL DEFAULT 'rotation'
            )
        """)
        mapping, seen = {}, {}
        for old_id, _block_id, name, eo, ch_id in old_shows:
            if ch_id is None:
                continue
            key = (ch_id, name)
            if key in seen:
                mapping[old_id] = seen[key]
            else:
                cur = self.conn.execute(
                    "INSERT INTO shows(channel_id, name, episode_order) VALUES (?, ?, ?)",
                    (ch_id, name, eo),
                )
                seen[key] = cur.lastrowid
                mapping[old_id] = cur.lastrowid
        for old_id, new_id in mapping.items():
            if old_id != new_id:
                self.conn.execute("UPDATE media SET show_id=? WHERE show_id=?", (new_id, old_id))
        for old_id, block_id, _n, _e, _c in old_shows:
            if block_id and old_id in mapping:
                self.conn.execute(
                    "INSERT OR IGNORE INTO block_shows(block_id, show_id) VALUES (?, ?)",
                    (block_id, mapping[old_id]),
                )
        self.conn.execute("PRAGMA foreign_keys = ON")

    def _migrate_media_to_groups(self):
        self.conn.execute(
            "UPDATE media SET kind='show_bumper' WHERE kind='bumper' AND show_id IS NOT NULL"
        )
        for (ch_id,) in self.conn.execute("SELECT id FROM channels").fetchall():
            has_ch = self.conn.execute(
                "SELECT 1 FROM media WHERE channel_id=? AND kind='bumper' "
                "AND block_id IS NULL AND show_id IS NULL LIMIT 1", (ch_id,)
            ).fetchone()
            ch_grp = None
            if has_ch:
                self.conn.execute(
                    "INSERT OR IGNORE INTO bumper_groups(channel_id, name) VALUES (?, ?)",
                    (ch_id, "Channel bumpers"),
                )
                ch_grp = self.conn.execute(
                    "SELECT id FROM bumper_groups WHERE channel_id=? AND name=?",
                    (ch_id, "Channel bumpers"),
                ).fetchone()[0]
                self.conn.execute(
                    "UPDATE media SET bumper_group_id=? WHERE channel_id=? AND kind='bumper' "
                    "AND block_id IS NULL AND show_id IS NULL",
                    (ch_grp, ch_id),
                )
            blocks = self.conn.execute(
                "SELECT id, name FROM blocks WHERE channel_id=?", (ch_id,)
            ).fetchall()
            for blk_id, blk_name in blocks:
                has_blk = self.conn.execute(
                    "SELECT 1 FROM media WHERE kind='bumper' AND block_id=? LIMIT 1",
                    (blk_id,),
                ).fetchone()
                if has_blk:
                    gname = f"{blk_name} bumpers"
                    self.conn.execute(
                        "INSERT OR IGNORE INTO bumper_groups(channel_id, name) VALUES (?, ?)",
                        (ch_id, gname),
                    )
                    gid = self.conn.execute(
                        "SELECT id FROM bumper_groups WHERE channel_id=? AND name=?",
                        (ch_id, gname),
                    ).fetchone()[0]
                    self.conn.execute(
                        "UPDATE media SET bumper_group_id=? WHERE kind='bumper' AND block_id=?",
                        (gid, blk_id),
                    )
                    self.conn.execute(
                        "INSERT OR IGNORE INTO block_bumper_groups(block_id, bumper_group_id) "
                        "VALUES (?, ?)", (blk_id, gid),
                    )
                elif ch_grp:
                    self.conn.execute(
                        "INSERT OR IGNORE INTO block_bumper_groups(block_id, bumper_group_id) "
                        "VALUES (?, ?)", (blk_id, ch_grp),
                    )
            if self.conn.execute(
                "SELECT 1 FROM media WHERE channel_id=? AND kind='commercial' LIMIT 1", (ch_id,)
            ).fetchone():
                self.conn.execute(
                    "INSERT OR IGNORE INTO commercial_groups(channel_id, name) VALUES (?, ?)",
                    (ch_id, "Default"),
                )
                gid = self.conn.execute(
                    "SELECT id FROM commercial_groups WHERE channel_id=? AND name=?",
                    (ch_id, "Default"),
                ).fetchone()[0]
                self.conn.execute(
                    "UPDATE media SET commercial_group_id=? WHERE channel_id=? AND kind='commercial'",
                    (gid, ch_id),
                )
                for blk_id, _ in blocks:
                    self.conn.execute(
                        "INSERT OR IGNORE INTO block_commercial_groups(block_id, commercial_group_id) "
                        "VALUES (?, ?)", (blk_id, gid),
                    )
        self.conn.execute("UPDATE media SET block_id = NULL")

    # ------------------------------------------------------------------
    def execute(self, sql, params=()):
        with self._lock:
            cur = self.conn.execute(sql, params)
            self.conn.commit()
            return cur

    def query(self, sql, params=()):
        with self._lock:
            return self.conn.execute(sql, params).fetchall()

    def query_one(self, sql, params=()):
        with self._lock:
            return self.conn.execute(sql, params).fetchone()

    # ---------- channels ----------
    def add_channel(self, name, number=None):
        return self.execute(
            "INSERT INTO channels(name, number) VALUES (?, ?)", (name, number)
        ).lastrowid

    def get_channels(self):
        return self.query("SELECT * FROM channels ORDER BY COALESCE(number, 9999), name")

    def get_channel(self, cid):
        return self.query_one("SELECT * FROM channels WHERE id=?", (cid,))

    def delete_channel(self, cid):
        self.execute("DELETE FROM media WHERE channel_id=?", (cid,))
        self.execute("DELETE FROM channels WHERE id=?", (cid,))

    # ---------- blocks ----------
    def add_block(self, channel_id, name, days, start_time, duration_minutes, shuffle_shows):
        return self.execute(
            "INSERT INTO blocks(channel_id, name, days, start_time, duration_minutes, shuffle_shows) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (channel_id, name, days, start_time, duration_minutes, int(shuffle_shows)),
        ).lastrowid

    def get_blocks(self, channel_id):
        return self.query(
            "SELECT * FROM blocks WHERE channel_id=? ORDER BY start_time", (channel_id,)
        )

    def delete_block(self, block_id):
        self.execute("DELETE FROM broadcast_anchor WHERE block_id=?", (block_id,))
        self.execute("DELETE FROM blocks WHERE id=?", (block_id,))

    # ---------- shows ----------
    def add_show(self, channel_id, name):
        return self.execute(
            "INSERT INTO shows(channel_id, name) VALUES (?, ?)", (channel_id, name)
        ).lastrowid

    def get_shows_for_channel(self, channel_id):
        return self.query(
            "SELECT * FROM shows WHERE channel_id=? ORDER BY name", (channel_id,)
        )

    def find_show(self, channel_id, name):
        return self.query_one(
            "SELECT * FROM shows WHERE channel_id=? AND name=?", (channel_id, name)
        )

    def get_block_shows(self, block_id):
        return self.query("""
            SELECT s.* FROM shows s
            JOIN block_shows bs ON bs.show_id = s.id
            WHERE bs.block_id = ?
            ORDER BY s.name
        """, (block_id,))

    def set_block_shows(self, block_id, show_ids):
        with self._lock:
            with self.conn:
                self.conn.execute("DELETE FROM block_shows WHERE block_id=?", (block_id,))
                self.conn.execute("DELETE FROM broadcast_anchor WHERE block_id=?", (block_id,))
                for sid in show_ids:
                    self.conn.execute(
                        "INSERT OR IGNORE INTO block_shows(block_id, show_id) VALUES (?, ?)",
                        (block_id, sid),
                    )

    # ---------- bumper / commercial groups ----------
    def add_bumper_group(self, channel_id, name):
        return self.execute(
            "INSERT INTO bumper_groups(channel_id, name) VALUES (?, ?)", (channel_id, name)
        ).lastrowid

    def add_commercial_group(self, channel_id, name):
        return self.execute(
            "INSERT INTO commercial_groups(channel_id, name) VALUES (?, ?)",
            (channel_id, name),
        ).lastrowid

    def get_bumper_groups(self, channel_id):
        return self.query(
            "SELECT * FROM bumper_groups WHERE channel_id=? ORDER BY name", (channel_id,)
        )

    def get_commercial_groups(self, channel_id):
        return self.query(
            "SELECT * FROM commercial_groups WHERE channel_id=? ORDER BY name", (channel_id,)
        )

    def get_block_bumper_groups(self, block_id):
        return self.query("""
            SELECT g.* FROM bumper_groups g
            JOIN block_bumper_groups bbg ON bbg.bumper_group_id = g.id
            WHERE bbg.block_id = ?
            ORDER BY g.name
        """, (block_id,))

    def get_block_commercial_groups(self, block_id):
        return self.query("""
            SELECT g.* FROM commercial_groups g
            JOIN block_commercial_groups bcg ON bcg.commercial_group_id = g.id
            WHERE bcg.block_id = ?
            ORDER BY g.name
        """, (block_id,))

    def set_block_bumper_groups(self, block_id, group_ids):
        with self._lock:
            with self.conn:
                self.conn.execute(
                    "DELETE FROM block_bumper_groups WHERE block_id=?", (block_id,)
                )
                self.conn.execute("DELETE FROM broadcast_anchor WHERE block_id=?", (block_id,))
                for gid in group_ids:
                    self.conn.execute(
                        "INSERT OR IGNORE INTO block_bumper_groups"
                        "(block_id, bumper_group_id) VALUES (?, ?)",
                        (block_id, gid),
                    )

    def set_block_commercial_groups(self, block_id, group_ids):
        with self._lock:
            with self.conn:
                self.conn.execute(
                    "DELETE FROM block_commercial_groups WHERE block_id=?", (block_id,)
                )
                self.conn.execute("DELETE FROM broadcast_anchor WHERE block_id=?", (block_id,))
                for gid in group_ids:
                    self.conn.execute(
                        "INSERT OR IGNORE INTO block_commercial_groups"
                        "(block_id, commercial_group_id) VALUES (?, ?)",
                        (block_id, gid),
                    )

    # ---------- media ----------
    def add_media(self, channel_id, show_id, kind, path, title, duration,
                  bumper_group_id=None, commercial_group_id=None):
        return self.execute(
            "INSERT OR IGNORE INTO media"
            "(channel_id, show_id, bumper_group_id, commercial_group_id, kind, path, title, duration) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (channel_id, show_id, bumper_group_id, commercial_group_id,
             kind, str(path), title, duration),
        ).lastrowid

    def mark_played(self, media_id):
        self.execute(
            "UPDATE media SET last_played=?, play_count=play_count+1 WHERE id=?",
            (time.time(), media_id),
        )

    def media_for_show(self, show_id):
        return self.query(
            "SELECT * FROM media WHERE show_id=? ORDER BY kind, title", (show_id,)
        )

    def media_for_bumper_group(self, group_id):
        return self.query(
            "SELECT * FROM media WHERE bumper_group_id=? ORDER BY title", (group_id,)
        )

    def media_for_commercial_group(self, group_id):
        return self.query(
            "SELECT * FROM media WHERE commercial_group_id=? ORDER BY title", (group_id,)
        )

    def media_for_channel(self, channel_id):
        return self.query(
            "SELECT * FROM media WHERE channel_id=? ORDER BY kind, title", (channel_id,)
        )

    def get_media_by_ids(self, ids):
        ids = list(dict.fromkeys(int(i) for i in ids))
        out = {}
        for i in range(0, len(ids), 500):
            chunk = ids[i:i + 500]
            ph = ",".join("?" * len(chunk))
            for r in self.query(f"SELECT * FROM media WHERE id IN ({ph})", tuple(chunk)):
                out[r["id"]] = r
        return out

    # ---------- broadcast state ----------
    def get_anchor(self, channel_id):
        return self.query_one(
            "SELECT * FROM broadcast_anchor WHERE channel_id=?", (channel_id,)
        )

    def set_anchor(self, channel_id, block_id, anchor_time, seed, playlist=None):
        self.execute(
            "INSERT INTO broadcast_anchor(channel_id, block_id, anchor_time, seed, playlist) "
            "VALUES (?, ?, ?, ?, ?) "
            "ON CONFLICT(channel_id) DO UPDATE SET "
            "block_id=excluded.block_id, anchor_time=excluded.anchor_time, "
            "seed=excluded.seed, playlist=excluded.playlist",
            (channel_id, block_id, anchor_time, seed, playlist),
        )

    def clear_anchors_for_block(self, block_id):
        self.execute("DELETE FROM broadcast_anchor WHERE block_id=?", (block_id,))

    def clear_anchor(self, channel_id):
        self.execute("DELETE FROM broadcast_anchor WHERE channel_id=?", (channel_id,))

    def get_position(self, channel_id):
        return self.query_one(
            "SELECT * FROM channel_position WHERE channel_id=?", (channel_id,)
        )

    def set_position(self, channel_id, media_id, position_seconds):
        self.execute(
            "INSERT INTO channel_position(channel_id, media_id, position_seconds, updated_at) "
            "VALUES (?, ?, ?, ?) "
            "ON CONFLICT(channel_id) DO UPDATE SET "
            "media_id=excluded.media_id, position_seconds=excluded.position_seconds, "
            "updated_at=excluded.updated_at",
            (channel_id, media_id, position_seconds, time.time()),
        )

    def clear_position(self, channel_id):
        self.execute("DELETE FROM channel_position WHERE channel_id=?", (channel_id,))

    # ---------- settings ----------
    def get_setting(self, key, default=None):
        row = self.query_one("SELECT value FROM settings WHERE key=?", (key,))
        return row["value"] if row else default

    def set_setting(self, key, value):
        self.execute(
            "INSERT INTO settings(key, value) VALUES (?, ?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, str(value)),
        )

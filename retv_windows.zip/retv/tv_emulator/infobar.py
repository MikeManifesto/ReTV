"""
TV-guide style info banner drawn on top of the mpv video.

Rendered with Pillow into an RGBA image and shown through mpv's image overlay.
If Pillow (or overlay support) is missing, `InfoBar.available` is False and the
player falls back to plain on-screen text.

    pip install pillow
"""
import math
import threading
import time
from datetime import datetime, timedelta
from functools import lru_cache
from pathlib import Path

try:
    from PIL import Image, ImageChops, ImageDraw, ImageFont
except Exception:  # Pillow not installed
    Image = None

_BOLD = ["segoeuib.ttf", "arialbd.ttf", "Arial Bold.ttf", "Helvetica Bold.ttf",
         "DejaVuSans-Bold.ttf", "LiberationSans-Bold.ttf", "NotoSans-Bold.ttf"]
_REG = ["segoeui.ttf", "arial.ttf", "Arial.ttf", "Helvetica.ttc",
        "DejaVuSans.ttf", "LiberationSans-Regular.ttf", "NotoSans-Regular.ttf"]


_C_BOLD = ["ARIALNB.TTF", "arialnb.ttf", "Arial Narrow Bold.ttf", "LiberationSansNarrow-Bold.ttf",
           "RobotoCondensed-Bold.ttf", "DejaVuSansCondensed-Bold.ttf", "NotoSansCondensed-Bold.ttf"]
_C_REG = ["ARIALN.TTF", "arialn.ttf", "Arial Narrow.ttf", "LiberationSansNarrow-Regular.ttf",
          "RobotoCondensed-Regular.ttf", "DejaVuSansCondensed.ttf", "NotoSansCondensed-Regular.ttf"]
_C_ITAL = ["ARIALNI.TTF", "arialni.ttf", "Arial Narrow Italic.ttf", "LiberationSansNarrow-Italic.ttf",
           "RobotoCondensed-Italic.ttf", "DejaVuSansCondensed-Oblique.ttf", "NotoSansCondensed-Italic.ttf"]


@lru_cache(maxsize=64)
def _cfont(style, size):
    """Condensed face used by the guide ("b" bold, "r" regular, "i" italic)."""
    names = {"b": _C_BOLD + _BOLD, "r": _C_REG + _REG, "i": _C_ITAL + _REG}[style]
    custom = _asset({"b": "guide-bold.ttf", "r": "guide-regular.ttf", "i": "guide-italic.ttf"}[style])
    if custom is not None:
        names = [str(custom)] + names
    for name in names:
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    return _font(style == "b", size)


@lru_cache(maxsize=64)
def _font(bold, size):
    for name in (_BOLD if bold else _REG):
        try:
            return ImageFont.truetype(name, size)
        except OSError:
            continue
    try:
        return ImageFont.load_default(size)
    except TypeError:
        return ImageFont.load_default()


def _fit(text, font, max_w, ell="…"):
    text = text or ""
    if max_w <= 0:
        return ""
    if font.getlength(text) <= max_w:
        return text
    while text and font.getlength(text + ell) > max_w:
        text = text[:-1]
    return text.rstrip() + ell


def clock(ts):
    dt = datetime.fromtimestamp(ts)
    return f"{dt.hour % 12 or 12}:{dt.minute:02d}{'a' if dt.hour < 12 else 'p'}"


def stamp(ts):
    dt = datetime.fromtimestamp(ts)
    return f"{dt.strftime('%a')} {dt.month}/{dt.day} {clock(ts)}"


@lru_cache(maxsize=8)
def _round_mask(w, h, r):
    k = 4
    m = Image.new("L", (w * k, h * k), 0)
    ImageDraw.Draw(m).rounded_rectangle((0, 0, w * k - 1, h * k - 1), radius=r * k, fill=255)
    return m.resize((w, h), Image.LANCZOS)


@lru_cache(maxsize=8)
def _bottom_mask(w, h, r):
    """Rectangle with only the two lower corners rounded."""
    k = 4
    m = Image.new("L", (w * k, h * k), 0)
    dm = ImageDraw.Draw(m)
    try:
        dm.rounded_rectangle((0, 0, w * k - 1, h * k - 1), radius=r * k, fill=255,
                             corners=(False, False, True, True))
    except TypeError:  # very old Pillow: round everything, then square the top
        dm.rounded_rectangle((0, 0, w * k - 1, h * k - 1), radius=r * k, fill=255)
        dm.rectangle((0, 0, w * k - 1, h * k // 2), fill=255)
    return m.resize((w, h), Image.LANCZOS)


_logo_cache = {}


def _load_logo(path):
    try:
        p = Path(path)
        key = (str(p), p.stat().st_mtime_ns)
    except Exception:
        return None
    if key not in _logo_cache:
        if len(_logo_cache) > 8:
            _logo_cache.clear()
        try:
            _logo_cache[key] = Image.open(p).convert("RGBA")
        except Exception:
            _logo_cache[key] = None
    return _logo_cache[key]


def _gradient(w, h, top, bottom):
    g = Image.new("RGBA", (w, h))
    d = ImageDraw.Draw(g)
    for y in range(h):
        t = y / max(1, h - 1)
        d.line([(0, y), (w, y)], fill=tuple(int(top[i] + (bottom[i] - top[i]) * t) for i in range(4)))
    return g


def render(info, osd_w, osd_h):
    """
    info keys: channel_number, channel_name, logo (path|None), title, subtitle,
               start_ts, end_ts, now_ts, next_title, block_name
    Returns an RGBA PIL image.
    """
    s = max(0.45, osd_h / 1080.0)
    u = lambda v: max(1, int(round(v * s)))

    W = int(osd_w)  # full width: the banner touches the screen edges
    H1, H2, H3 = u(132), u(58), u(46)
    H = H1 + H2 + H3
    pad = u(28)

    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    img.paste(_gradient(W, H1, (46, 116, 200, 244), (14, 60, 136, 244)), (0, 0))
    img.paste(Image.new("RGBA", (W, H2), (238, 242, 247, 246)), (0, H1))
    inset = int(W * 0.06)          # bottom strip is narrower than the rest
    SW = W - 2 * inset
    strip = _gradient(SW, H3, (28, 88, 168, 244), (16, 62, 132, 244))
    strip.putalpha(ImageChops.multiply(strip.getchannel("A"), _bottom_mask(SW, H3, u(18))))
    img.paste(strip, (inset, H1 + H2))
    d = ImageDraw.Draw(img)

    WHITE = (255, 255, 255, 255)
    SOFT = (208, 226, 252, 255)
    DARK = (27, 36, 48, 255)
    MUTED = (84, 98, 118, 255)

    # ---- header: logo | number + name | title + subtitle | block ----------
    lx0, ly0 = pad, u(14)
    lw, lh = u(156), H1 - 2 * u(14)
    logo = _load_logo(info["logo"]) if info.get("logo") else None
    if logo is not None:
        box = (lw - u(20), lh - u(16))
        lg = logo.copy()
        lg.thumbnail(box, Image.LANCZOS)
        img.paste(lg, (lx0 + (lw - lg.width) // 2, ly0 + (lh - lg.height) // 2), lg)
    else:
        f = _font(True, u(34))
        t = _fit((info.get("channel_name") or "TV").upper(), f, lw - u(16))
        d.text((lx0 + lw / 2, ly0 + lh / 2), t, font=f, fill=WHITE, anchor="mm")

    x = lx0 + lw + u(26)
    num = info.get("channel_number")
    name = info.get("channel_name") or ""
    if num is not None:
        fn, fs = _font(True, u(54)), _font(False, u(27))
        d.text((x, u(14)), str(num), font=fn, fill=WHITE)
        d.text((x, u(14) + u(64)), _fit(name, fs, u(230)), font=fs, fill=SOFT)
        colw = max(fn.getlength(str(num)), min(fs.getlength(name), u(230)))
    else:
        fn = _font(True, u(34))
        d.text((x, u(30)), _fit(name, fn, u(260)), font=fn, fill=WHITE)
        colw = min(fn.getlength(name), u(260))
    tx = x + colw + u(36)

    block = info.get("block_name") or ""
    fb = _font(False, u(24))
    bw = min(fb.getlength(block), u(260)) if block else 0
    if block:
        d.text((W - pad, u(20)), _fit(block, fb, u(260)), font=fb, fill=SOFT, anchor="ra")
    tmax = W - pad - bw - u(30) - tx

    ft, fsub = _font(True, u(46)), _font(False, u(29))
    d.text((tx, u(16)), _fit(info.get("title") or "", ft, tmax), font=ft, fill=WHITE)
    sub = info.get("subtitle") or ""
    if sub and sub.strip().lower() != (info.get("title") or "").strip().lower():
        d.text((tx, u(16) + u(60)), _fit(sub, fsub, tmax), font=fsub, fill=SOFT)

    # ---- middle strip: date/time | progress | up next ---------------------
    my = H1 + H2 / 2
    fm, fmb = _font(False, u(25)), _font(True, u(26))
    d.text((pad, my), stamp(info["now_ts"]), font=fmb, fill=DARK, anchor="lm")

    bx0 = pad + u(262)
    bx1 = int(W * 0.60)
    fl = _font(False, u(24))
    sl, el = clock(info["start_ts"]), clock(info["end_ts"])
    d.text((bx0, my), sl, font=fl, fill=MUTED, anchor="lm")
    ebx0 = bx0 + fl.getlength(sl) + u(14)
    ebx1 = bx1 - fl.getlength(el) - u(14)
    bh = u(12)
    d.rounded_rectangle((ebx0, my - bh / 2, ebx1, my + bh / 2), radius=bh // 2, fill=(196, 204, 216, 255))
    span = max(1.0, info["end_ts"] - info["start_ts"])
    frac = min(1.0, max(0.0, (info["now_ts"] - info["start_ts"]) / span))
    if frac > 0:
        fx = ebx0 + (ebx1 - ebx0) * frac
        d.rounded_rectangle((ebx0, my - bh / 2, max(ebx0 + bh, fx), my + bh / 2),
                            radius=bh // 2, fill=(38, 114, 202, 255))
    d.text((bx1, my), el, font=fl, fill=MUTED, anchor="rm")

    nxt = info.get("next_title") or ""
    if nxt:
        lab = "Up next:  "
        d.text((int(W * 0.63), my), lab, font=fmb, fill=MUTED, anchor="lm")
        nx = int(W * 0.63) + fmb.getlength(lab)
        d.text((nx, my), _fit(nxt, fm, W - pad - nx), font=fm, fill=DARK, anchor="lm")

    # ---- bottom strip: time left | key hints ------------------------------
    by = H1 + H2 + H3 / 2
    fh = _font(False, u(23))
    left = max(0, info["end_ts"] - info["now_ts"])
    d.text((inset + pad, by), f"{math.ceil(left / 60)} min left", font=fh, fill=WHITE, anchor="lm")
    hints = "Up/Down  Channel      0-9  Go to channel      F  Fullscreen      G  Guide      Esc  Exit"
    d.text((W - inset - pad, by), _fit(hints, fh, SW - 2 * pad - u(190)), font=fh, fill=SOFT, anchor="rm")

    return img


# ---------------------------------------------------------------------------
# On-screen guide (modelled on a DirecTV guide screenshot)
# ---------------------------------------------------------------------------
# Optional red promo row (like "DIRECTV ONDEMAND" in the reference picture).
# Off by default because it is purely decorative.  Example:
#     GUIDE_PROMO_BAR = ("RETV", "ONDEMAND", "")
GUIDE_PROMO_BAR = None

# Footer buttons (colour, label).  The first two are real: [ and ] jump
# -12 / +12 hours.  The last two only exist to match the reference picture.
GUIDE_FOOTER = [((226, 70, 60), "-12 hrs"), ((70, 200, 90), "+12 hrs"),
                ((236, 200, 60), "Guide Options"), ((70, 190, 232), "Search")]


def short_stamp(ts):
    dt = datetime.fromtimestamp(ts)
    return f"{dt.strftime('%a')} {clock(ts)}"


def _wrap(text, font, max_w, max_lines):
    words = (text or "").split()
    lines, cur = [], ""
    for i, wd in enumerate(words):
        t = (cur + " " + wd).strip()
        if cur and font.getlength(t) > max_w:
            lines.append(cur)
            if len(lines) == max_lines:
                lines[-1] = _fit(lines[-1] + " " + " ".join(words[i:]), font, max_w)
                return lines
            cur = wd
        else:
            cur = t
    if cur:
        lines.append(cur)
    return [_fit(ln, font, max_w) for ln in lines]


def _asset(name):
    """Find a file in the `assets` folder at the program root.  The root may be
    this package folder or the folder above it, so check both (and the
    working directory)."""
    here = Path(__file__).resolve().parent
    for base in (here, here.parent, Path.cwd()):
        p = base / "assets" / name
        if p.exists():
            return p
    return None


def _logo_path():
    return _asset("retv-logo.png")


def _hgradient(w, h, left, right):
    g = Image.new("RGBA", (w, h))
    d = ImageDraw.Draw(g)
    for x in range(w):
        t = x / max(1, w - 1)
        d.line([(x, 0), (x, h)], fill=tuple(int(left[i] + (right[i] - left[i]) * t) for i in range(4)))
    return g


def guide_geometry(w, h, dar):
    """Layout numbers shared by the renderer and the live-preview placement.
    Everything is measured in "reference pixels" of the 471x358 screenshot and
    scaled by the screen height (r(v))."""
    R = h / 348.0
    r = lambda v: max(1, int(round(v * R)))
    dar = dar if dar and dar > 0.2 else 16 / 9
    ph = r(85)
    pw = int(round(ph * dar))
    if pw > w * 0.40:
        pw = int(w * 0.40)
        ph = int(round(pw / dar))
    return dict(r=r, w=w, h=h, dar=dar, pw=pw, ph=ph, px=w - r(16) - pw, py=r(23))


def render_guide(model, osd_w, osd_h, geo=None):
    """Draw the whole guide as a full-screen RGBA image.  The preview rectangle
    in the top-right is left fully transparent: the live video (scaled down by
    mpv) shows through it."""
    W, H = int(osd_w), int(osd_h)
    geo = geo or guide_geometry(W, H, 16 / 9)
    r, px, py, pw, ph = geo["r"], geo["px"], geo["py"], geo["pw"], geo["ph"]
    now_ts = model.now_ts

    # palette (sampled from the reference picture)
    BG = (5, 100, 188)
    PALE_L, PALE_R = (242, 246, 250, 255), (186, 218, 238, 255)
    TAB1, TAB2 = (176, 196, 214, 255), (230, 239, 246, 255)
    TITLE = (26, 98, 176, 255)
    TABTXT = (22, 66, 132, 255)
    NAVY = (4, 40, 118, 255)
    CHAN = (3, 52, 136, 255)
    MONBOX = (34, 82, 152, 255)
    CELL = (3, 86, 176, 255)
    DIV = (2, 56, 132, 255)
    LBLUE = (100, 176, 220, 255)
    WHITE = (255, 255, 255, 255)

    img = Image.new("RGBA", (W, H), BG)
    d = ImageDraw.Draw(img)
    T = lambda xy, txt, f, fill, anc="lm": d.text(xy, txt, font=f, fill=fill, anchor=anc)

    sel_ch = model.selected_channel() if model.channels else None
    sel = model.selected_cell() if model.channels else None

    # ============================ header ==================================
    band_top, band_bot = r(70), r(98)
    img.paste(_hgradient(W, band_bot, PALE_L, PALE_R), (0, 0))

    # faint "guide" watermark
    T((px - r(12), r(35)), "guide", _cfont("r", r(28)), (168, 198, 220, 255), "rs")

    # logo: transparent background, drawn straight onto the header
    lp = _logo_path()
    logo = _load_logo(str(lp)) if lp else None
    lx, lbox_w, lbox_h = r(24), r(100), r(54)
    if logo is not None:
        lg = logo.copy()
        lg.thumbnail((lbox_w, lbox_h), Image.LANCZOS)
        img.paste(lg, (lx, r(8) + (lbox_h - lg.height) // 2), lg)
        logo_right = lx + lg.width
    else:
        f = _cfont("b", r(26))
        T((lx, r(36)), "RETV", f, TITLE)
        logo_right = lx + int(f.getlength("RETV"))

    # title of the highlighted program
    tx = max(r(115), logo_right + r(14))
    ft = _cfont("b", r(17))
    T((tx, r(58)), _fit(sel.title if sel else "No Information", ft, px - r(10) - tx), ft, TITLE)

    # info band: [ Mon 3:13p ] [ 3:05p - 3:35p ............ No Rating ]
    fb = _cfont("b", r(12))
    t1_x0, t1_x1 = r(5), r(105)
    t2_x0, t2_x1 = r(110), px - r(6)
    img.paste(_gradient(t1_x1 - t1_x0, band_bot - band_top, (186, 204, 220, 255), (164, 186, 206, 255)),
              (t1_x0, band_top))
    d.rectangle((t2_x0, band_top, t2_x1, band_bot), fill=TAB2)
    T(((t1_x0 + t1_x1) // 2, (band_top + band_bot) // 2 + 1), short_stamp(now_ts), fb, TABTXT, "mm")
    cy = (band_top + band_bot) // 2 + 1
    if sel and sel.kind != "gap":
        T((t2_x0 + r(10), cy), f"{clock(sel.start)} - {clock(sel.end)}", fb, TABTXT)
    T((t2_x1 - r(10), cy), "No Rating", _cfont("i", r(12)), TABTXT, "rm")

    # description (white on blue)
    if sel and sel_ch:
        from .guide import describe
        desc = describe(sel_ch, sel)
    else:
        desc = "No description available."
    fd = _cfont("b", r(12))
    for i, ln in enumerate(_wrap(desc, fd, px - r(64), 3)):
        T((r(40), r(114) + i * r(18)), ln, fd, WHITE)

    # preview frame (outside the transparent hole)
    b = max(2, r(2))
    d.rectangle((px - b, py - b, px + pw + b, py + ph + b), fill=(222, 234, 243, 255))

    # ============================= grid ===================================
    x_ch0, x_ch1 = r(39), r(110)
    gx0, gx1 = x_ch1, W - r(16)
    n_slots = int(model.span // 1800)
    colw = (gx1 - gx0) / float(n_slots)
    y_time, time_h = r(163), r(17)
    y_rows = r(183)
    row_h = max(2, int(round(22.5 * geo["r"](1))))
    n_cells = max(1, int((r(318) - y_rows + r(1)) // row_h))     # visible rows incl. promo
    promo = GUIDE_PROMO_BAR if n_cells > 3 else None
    n_vis = n_cells - (1 if promo else 0)
    model.n_vis = max(1, n_vis)

    n_ch = len(model.channels)
    if model.sel_row < model.row_off:
        model.row_off = model.sel_row
    elif model.sel_row >= model.row_off + n_vis:
        model.row_off = model.sel_row - n_vis + 1
    model.row_off = max(0, min(model.row_off, max(0, n_ch - n_vis)))

    t0 = model.t0
    t1_ = t0 + model.span
    xof = lambda ts: gx0 + (ts - t0) / 1800.0 * colw

    # time strip
    d.rectangle((x_ch0, y_time, gx1, y_time + time_h), fill=NAVY)
    d.rectangle((x_ch0, y_time, x_ch1 - 1, y_time + time_h), fill=MONBOX)
    fth = _cfont("b", r(12))
    cyt = y_time + time_h // 2
    T((x_ch0 + r(5), cyt), datetime.fromtimestamp(t0).strftime("%a %m/%d").replace("/0", "/"), fth, WHITE)
    for i in range(n_slots):
        T((gx0 + i * colw + r(12), cyt), clock(t0 + i * 1800), fth, WHITE)
    if t0 <= now_ts < t1_:                          # small white "now" tick
        nx = xof(now_ts)
        d.line([(nx - r(4), y_time + time_h + r(2)), (nx + r(4), y_time + time_h + r(2))],
               fill=WHITE, width=max(2, r(1.5)))

    # rows
    fch = _cfont("r", r(12))
    fcell = _cfont("b", r(11.5))
    farrow = _cfont("b", r(11.5))
    ftiny = _cfont("b", r(8))
    k = 0
    for slot in range(n_cells):
        y = y_rows + slot * row_h
        if promo and slot == 3:                     # decorative red bar
            d.rectangle((x_ch0, y + 1, gx1, y + row_h - 1), fill=(188, 38, 54, 255))
            d.line([(x_ch0, y + 1), (gx1, y + 1)], fill=(224, 92, 100, 255), width=1)
            fp = _cfont("b", r(13))
            brand, ital, right = promo
            T((r(62), y + row_h // 2), brand, fp, WHITE)
            T((r(62) + int(fp.getlength(brand)) + r(5), y + row_h // 2), ital, _cfont("i", r(13)), WHITE)
            if right:
                T((gx1 - r(8), y + row_h // 2), right, ftiny, WHITE, "rm")
            continue
        ri = model.row_off + k
        k += 1
        if ri >= n_ch:
            continue
        ch = model.channels[ri]
        is_row_sel = ri == model.sel_row
        cy = y + row_h // 2

        d.rectangle((x_ch0, y, x_ch1 - 1, y + row_h - 1), fill=CHAN)
        label = f"{ch['number']} {ch['name']}" if ch["number"] is not None else ch["name"]
        T((x_ch0 + r(5), cy), _fit(label, fch, x_ch1 - x_ch0 - r(8), "..."), fch, LBLUE)

        d.rectangle((gx0, y, gx1, y + row_h - 1), fill=CELL)
        sel_box = None
        for c in model.rows[ri]:
            if c.end <= t0 or c.start >= t1_:
                continue
            x0, x1 = max(gx0, int(xof(c.start))), min(gx1, int(xof(c.end)))
            if x1 - x0 < r(6):
                continue
            is_sel = is_row_sel and c is sel
            if c.start >= t0 and x0 > gx0:          # divider on the cell's left edge
                d.line([(x0, y), (x0, y + row_h - 1)], fill=DIV, width=max(1, r(1)))
            tl, tr = x0 + r(7), x1 - r(6)
            tcol = (52, 30, 0, 255) if is_sel else (WHITE if c.kind != "gap" else (150, 205, 238, 255))
            if c.start < t0 - 1:                    # began before the visible window
                T((x0 + r(3), cy), "<", farrow, tcol)
                tl = x0 + r(13)
            more = c.end > t1_ + 1
            if more:                                # continues past the visible window
                tr = x1 - r(9)
            if tr - tl > r(8):
                T((tl, cy), _fit(c.title, fcell, tr - tl, "..."), fcell, tcol)
            if more:
                T((x1 - r(3), y + row_h * 0.38), ">", ftiny, (150, 205, 240, 255), "rm")
            if is_sel:
                sel_box = (x0, y, x1, y + row_h - 1, c, tl, tr, cy, tcol)
        if sel_box:                                 # orange highlight drawn last
            x0, y_, x1, y1, c, tl, tr, cy_, _ = sel_box
            gb = _gradient(max(1, x1 - x0), max(1, y1 - y_ + 1), (246, 184, 52, 255), (222, 140, 18, 255))
            img.paste(gb, (x0, y_))
            d.rectangle((x0, y_, x1, y1), outline=(255, 214, 120, 255), width=max(1, r(1)))
            fsel = _cfont("b", r(11.5))
            if tr - tl > r(8):
                T((tl, cy_), _fit(c.title, fsel, tr - tl, "..."), fsel, (52, 30, 0, 255))
        d.line([(x_ch0, y), (gx1, y)], fill=DIV, width=1)   # row separator

    # more-rows hints (tiny, in the right margin)
    ax = W - r(8)
    if model.row_off > 0:
        d.polygon([(ax, y_rows + r(3)), (ax - r(3), y_rows + r(8)), (ax + r(3), y_rows + r(8))], fill=LBLUE)
    if model.row_off + n_vis < n_ch:
        yb = y_rows + n_cells * row_h - r(3)
        d.polygon([(ax, yb), (ax - r(3), yb - r(5)), (ax + r(3), yb - r(5))], fill=LBLUE)

    # ============================ footer ==================================
    ff = _cfont("r", r(11))
    fy = r(323)
    T((r(49), fy), "All Channels", ff, LBLUE)
    x = W - r(34)
    for col, label in reversed(GUIDE_FOOTER):
        lw_ = int(ff.getlength(label))
        T((x - lw_, fy), label, ff, LBLUE)
        x -= lw_ + r(4)
        rad = max(2, r(3.2))
        d.ellipse((x - 2 * rad, fy - rad, x, fy + rad), fill=col + (255,))
        d.ellipse((x - 2 * rad + 1, fy - rad + 1, x - rad, fy - 1), fill=tuple(min(255, c + 70) for c in col) + (255,))
        x -= 2 * rad + r(12)

    # ====================== live preview "window" =========================
    img.paste((0, 0, 0, 0), (px, py, px + pw, py + ph))
    return img


class InfoBar:
    """Shows/refreshes/hides the banner or the guide on a python-mpv `MPV`."""

    def __init__(self, mpv_player):
        self.m = mpv_player
        self._lock = threading.RLock()
        self._ov = None
        self._timer = None
        self._visible = False
        self._mode = None            # None | "bar" | "guide"
        self._guide = None
        self.available = Image is not None and hasattr(mpv_player, "create_image_overlay")

    @property
    def visible(self):
        return self._visible

    @property
    def guide_open(self):
        return self._visible and self._mode == "guide"

    @property
    def guide_model(self):
        return self._guide if self.guide_open else None

    def _osd_size(self):
        try:
            w, h = int(self.m.osd_width or 0), int(self.m.osd_height or 0)
        except Exception:
            w = h = 0
        return (w, h) if w > 0 and h > 0 else (1280, 720)

    def _drop_overlay(self):
        if self._ov is not None:
            try:
                self._ov.remove()
            except Exception:
                pass
            self._ov = None

    def _put(self, img, pos):
        if self._ov is None:
            self._ov = self.m.create_image_overlay(img, pos=pos)
        else:
            self._ov.update(img, pos=pos)

    # ---------------------------------------------------------------- banner
    def _draw(self, info):
        w, h = self._osd_size()
        img = render(info, w, h)
        self._put(img, ((w - img.width) // 2, 0))

    def show(self, info, seconds=8.0):
        """Returns True if the banner is on screen."""
        if not self.available or info is None:
            return False
        with self._lock:
            if self._mode == "guide":        # never cover the guide
                return True
            try:
                self._draw(info)
            except Exception:
                self.available = False
                return False
            self._visible = True
            self._mode = "bar"
            if self._timer is not None:
                self._timer.cancel()
            self._timer = threading.Timer(seconds, self.hide)
            self._timer.daemon = True
            self._timer.start()
            return True

    def refresh(self, info):
        if not self._visible or self._mode != "bar" or info is None:
            return
        with self._lock:
            if not self._visible or self._mode != "bar":
                return
            try:
                self._draw(info)
            except Exception:
                pass

    # ----------------------------------------------------------------- guide
    def _video_dar(self):
        try:
            dw, dh = self.m.dwidth, self.m.dheight
            if dw and dh:
                return float(dw) / float(dh)
        except Exception:
            pass
        return 16 / 9

    def _place_preview(self, geo):
        """Fit the playing video exactly into the preview window (top-right).
        mpv's video margins shrink the area the video is fitted into; the
        overlay still covers the whole window."""
        w, h, px, py, pw, ph = geo["w"], geo["h"], geo["px"], geo["py"], geo["pw"], geo["ph"]
        try:
            self.m.video_zoom = 0
            self.m.video_align_x = 0
            self.m.video_align_y = 0
            self.m.video_pan_x = 0
            self.m.video_pan_y = 0
            self.m.video_margin_ratio_left = px / w
            self.m.video_margin_ratio_right = (w - px - pw) / w
            self.m.video_margin_ratio_top = py / h
            self.m.video_margin_ratio_bottom = (h - py - ph) / h
            return
        except Exception:
            pass
        # fallback for mpv builds without video margins: zoom + align + pan
        try:
            base_w = min(w, h * geo["dar"])
            self.m.video_zoom = math.log2(max(0.02, pw / base_w))
            self.m.video_align_x = 1.0
            self.m.video_align_y = -1.0
            self.m.video_pan_x = -(w - px - pw) / float(pw)
            self.m.video_pan_y = py / float(ph)
        except Exception:
            pass

    def _restore_video(self):
        for prop, val in (("video_margin_ratio_left", 0), ("video_margin_ratio_right", 0),
                          ("video_margin_ratio_top", 0), ("video_margin_ratio_bottom", 0),
                          ("video_zoom", 0), ("video_align_x", 0), ("video_align_y", 0),
                          ("video_pan_x", 0), ("video_pan_y", 0)):
            try:
                setattr(self.m, prop, val)
            except Exception:
                pass

    def _draw_guide(self, model):
        w, h = self._osd_size()
        geo = guide_geometry(w, h, self._video_dar())
        self._place_preview(geo)
        img = render_guide(model, w, h, geo)
        self._put(img, (0, 0))
        model.last_draw = time.time()

    def show_guide(self, model):
        if not self.available:
            return False
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
            if self._mode != "guide":
                self._drop_overlay()         # banner and guide differ in size
            try:
                self._draw_guide(model)
            except Exception as e:
                print(f"Guide render error: {e}")
                self._drop_overlay()
                self._restore_video()
                self._visible, self._mode, self._guide = False, None, None
                return False
            self._visible = True
            self._mode = "guide"
            self._guide = model
            return True

    def redraw_guide(self):
        with self._lock:
            if not self.guide_open:
                return
            try:
                self._draw_guide(self._guide)
            except Exception as e:
                print(f"Guide render error: {e}")

    def tick_guide(self, now_ts, every=30.0):
        """Keep the clock / 'now' marker fresh while the guide stays open."""
        m = self.guide_model
        if m is not None and now_ts - m.last_draw >= every:
            m.now_ts = now_ts
            self.redraw_guide()

    # ------------------------------------------------------------------ hide
    def hide(self):
        with self._lock:
            if self._timer is not None:
                self._timer.cancel()
                self._timer = None
            was_guide = self._mode == "guide"
            self._visible = False
            self._mode = None
            self._guide = None
            self._drop_overlay()
            if was_guide:
                self._restore_video()

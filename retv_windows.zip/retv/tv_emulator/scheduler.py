import bisect
import json
import random
import time as _time
from pathlib import Path
from dataclasses import dataclass
from datetime import datetime, time as dtime, timedelta

DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


# ---------------------------------------------------------------------------
# Schedule lookup
# ---------------------------------------------------------------------------
def block_window(block, date):
    h, m = map(int, block["start_time"].split(":"))
    start = datetime.combine(date, dtime(h, m))
    end = start + timedelta(minutes=block["duration_minutes"])
    return start, end


def current_block(db, channel_id, now=None):
    """Return (block, start, end) of the block airing at `now`, or None.
    If blocks overlap, the one that started most recently wins."""
    now = now or datetime.now()
    best = None
    for b in db.get_blocks(channel_id):
        days = {int(x) for x in b["days"].split(",") if x != ""}
        for delta in (0, -1):
            d = (now + timedelta(days=delta)).date()
            if d.weekday() not in days:
                continue
            s, e = block_window(b, d)
            if s <= now < e and (best is None or s > best[1]):
                best = (b, s, e)
    return best


def block_occurrences(db, channel_id, lo_ts, hi_ts):
    """Yield (block, start_ts, end_ts) for all blocks overlapping [lo_ts, hi_ts)."""
    lo_dt = datetime.fromtimestamp(lo_ts)
    hi_dt = datetime.fromtimestamp(hi_ts)

    # Start a day before to catch blocks that started yesterday and are still airing.
    d = lo_dt.date() - timedelta(days=1)
    # End a day after to catch blocks that start today and end tomorrow.
    end_d = hi_dt.date() + timedelta(days=1)

    blocks = db.get_blocks(channel_id)

    while d <= end_d:
        for b in blocks:
            days = {int(x) for x in b["days"].split(",") if x != ""}
            if d.weekday() in days:
                s, e = block_window(b, d)
                s_ts = s.timestamp()
                e_ts = e.timestamp()
                if s_ts < hi_ts and e_ts > lo_ts:
                    yield b, s_ts, e_ts
        d += timedelta(days=1)


# ---------------------------------------------------------------------------
# Playlist generation
# ---------------------------------------------------------------------------
def _pick_one(rows, order, rng, plays, last_id):
    """
    Pick one row.  `plays` counts how often each item was already picked in
    THIS playlist build, so everything is used once before anything repeats
    (the build never depends on mutable state beyond the initial last_played).
    """
    rows = [r for r in rows if (r["duration"] or 0) > 0]
    if not rows:
        return None
    if order == "random":
        pool = [r for r in rows if r["id"] != last_id] or rows
        return rng.choice(pool)

    floor = min(plays.get(r["id"], 0) for r in rows)
    fresh = [r for r in rows if plays.get(r["id"], 0) == floor]
    if order == "sequential":
        fresh.sort(key=lambda r: (r["last_played"], r["title"] or r["path"]))
        return fresh[0]
    fresh.sort(key=lambda r: r["last_played"])
    pool = fresh[:3]
    pool = [r for r in pool if r["id"] != last_id] or pool
    return rng.choice(pool)


class _Picker:
    def __init__(self, rng):
        self.rng = rng
        self.plays = {}
        self.last = {}

    def pick(self, rows, order, slot):
        r = _pick_one(rows, order, self.rng, self.plays, self.last.get(slot))
        if r is not None:
            self.plays[r["id"]] = self.plays.get(r["id"], 0) + 1
            self.last[slot] = r["id"]
        return r


def _group_rows(db, kind, group_ids, id_column):
    if not group_ids:
        return []
    ph = ",".join("?" * len(group_ids))
    return db.query(
        f"SELECT * FROM media WHERE kind=? AND {id_column} IN ({ph})",
        (kind, *group_ids),
    )


def build_playlist(db, block, seed, shuffle_shows=None):
    """Generate a playlist (list of media rows) that covers the block."""
    if shuffle_shows is None:
        shuffle_shows = block["shuffle_shows"]

    target = block["duration_minutes"] * 60
    shows = list(db.get_block_shows(block["id"]))
    if not shows:
        return []

    channel = db.get_channel(block["channel_id"])
    bumper_order = channel["bumper_order"] if channel else "rotation"
    commercial_order = channel["commercial_order"] if channel else "rotation"
    bumper_ids = [g["id"] for g in db.get_block_bumper_groups(block["id"])]
    commercial_ids = [g["id"] for g in db.get_block_commercial_groups(block["id"])]

    bumpers = _group_rows(db, "bumper", bumper_ids, "bumper_group_id")
    commercials = _group_rows(db, "commercial", commercial_ids, "commercial_group_id")
    show_media = {s["id"]: db.media_for_show(s["id"]) for s in shows}

    rng = random.Random(seed)
    picker = _Picker(rng)
    if shuffle_shows:
        rng.shuffle(shows)

    playlist = []
    total = 0.0
    i = 0
    empty_streak = 0
    guard = 0

    while total < target and guard < 5000:
        guard += 1
        show = shows[i % len(shows)]
        i += 1
        media = show_media[show["id"]]

        ep = picker.pick(
            [r for r in media if r["kind"] == "episode"],
            show["episode_order"], ("ep", show["id"]),
        )
        if ep is None:
            empty_streak += 1
            if empty_streak >= len(shows):
                break  # no show has playable episodes
            continue
        empty_streak = 0

        sb = picker.pick(
            [r for r in media if r["kind"] == "show_bumper"],
            "rotation", ("sb", show["id"]),
        )
        if sb:
            playlist.append(sb)
            total += sb["duration"]

        playlist.append(ep)
        total += ep["duration"]

        for _ in range(rng.randint(1, 2)):
            c = picker.pick(commercials, commercial_order, "commercial")
            if c:
                playlist.append(c)
                total += c["duration"]

        b = picker.pick(bumpers, bumper_order, "bumper")
        if b:
            playlist.append(b)
            total += b["duration"]

    return playlist


# ---------------------------------------------------------------------------
# The "airing" – a frozen, wall-clock-driven timeline for one block occurrence
# ---------------------------------------------------------------------------
@dataclass
class Spot:
    idx: int
    media_id: int
    duration: float
    offset: float      # seconds into the item that is airing right now
    remaining: float   # seconds until this item's slot ends


class Airing:
    """
    The playlist for one occurrence of a block, frozen when first created.
    Position is a pure function of the wall clock:
        elapsed = now - block_start  ->  (item, offset)
    """

    def __init__(self, channel_id, block, block_start, block_end,
                 anchor_time, seed, entries):
        self.channel_id = channel_id
        self.block = block
        self.block_start = block_start
        self.block_end = block_end
        self.anchor_time = anchor_time
        self.entries = entries                    # [(media_id, duration)]
        self.token = (block["id"], anchor_time, seed)
        self._end_ts = block_end.timestamp()
        self.starts = []
        t = 0.0
        for _mid, dur in entries:
            self.starts.append(t)
            t += dur
        self.total = t

    @property
    def empty(self):
        return not self.entries

    def locate(self, now_ts=None):
        """Return the Spot airing at now_ts, or None if the block is over/empty."""
        now_ts = _time.time() if now_ts is None else now_ts
        if self.empty or self.total <= 0 or now_ts >= self._end_ts:
            return None
        elapsed = max(0.0, now_ts - self.anchor_time)
        if elapsed >= self.total:
            elapsed %= self.total
        idx = bisect.bisect_right(self.starts, elapsed) - 1
        idx = max(0, min(idx, len(self.entries) - 1))
        mid, dur = self.entries[idx]
        off = elapsed - self.starts[idx]
        return Spot(idx, mid, dur, off, max(0.0, dur - off))

    def next_media_id(self, idx):
        if not self.entries:
            return None
        return self.entries[(idx + 1) % len(self.entries)][0]


def _decode(text):
    try:
        data = json.loads(text) if text else None
        out = [(int(i), float(d)) for i, d in data]
        return out or None
    except Exception:
        return None


def now_airing(db, channel_id, now=None):
    """
    Return the Airing for this channel right now (or None when off air).

    The playlist is generated ONCE per block occurrence and stored in the
    anchor, so leaving and re-entering a channel always lands exactly where
    the broadcast clock says it should.
    """
    now = now or datetime.now()
    cur = current_block(db, channel_id, now)
    if cur is None:
        return None
    block, start, end = cur
    anchor_time = start.timestamp()

    anchor = db.get_anchor(channel_id)
    entries = None
    seed = None
    # Anchor must belong to THIS occurrence (same block, same start time),
    # not merely the same block on a previous day.
    if (
        anchor is not None
        and anchor["block_id"] == block["id"]
        and abs(anchor["anchor_time"] - anchor_time) < 1.0
    ):
        entries = _decode(anchor["playlist"])
        if entries:
            seed = anchor["seed"]
            ids = list(dict.fromkeys(m for m, _ in entries))[:200]
            if not db.get_media_by_ids(ids):
                entries = None  # every item vanished -> rebuild

    if not entries:
        seed = random.randint(1, 2**31 - 1)
        playlist = build_playlist(db, block, seed)
        entries = [(r["id"], float(r["duration"]))
                   for r in playlist if (r["duration"] or 0) > 0]
        if entries:
            db.set_anchor(channel_id, block["id"], anchor_time, seed,
                          json.dumps(entries))
        else:
            seed = 0

    return Airing(channel_id, block, start, end, anchor_time, seed, entries)


# ---------------------------------------------------------------------------
# Programs: "[show bumper] episode [commercials] [bumper]" = one guide slot
# ---------------------------------------------------------------------------
@dataclass
class Program:
    start: float            # seconds from the airing's start
    end: float
    show_id: object = None
    show_name: str = ""
    title: str = ""         # episode title
    has_ep: bool = False


_PROGRAM_CACHE = {}


def programs_for(db, airing):
    """Return (programs, item_to_program_index) for an Airing (cached)."""
    hit = _PROGRAM_CACHE.get(airing.token)
    if hit is not None:
        return hit
    rows = db.get_media_by_ids([m for m, _ in airing.entries])
    shows = {r["id"]: r["name"] for r in
             db.query("SELECT id, name FROM shows WHERE channel_id=?", (airing.channel_id,))}
    progs, item_prog = [], []
    cur = None

    def new(start, end, sid):
        p = Program(start, end, sid, shows.get(sid, ""))
        progs.append(p)
        return p

    for (mid, dur), start in zip(airing.entries, airing.starts):
        r = rows.get(mid)
        kind = r["kind"] if r else "filler"
        sid = r["show_id"] if r else None
        end = start + dur
        if kind == "show_bumper":
            if cur is None or cur.has_ep or cur.show_id != sid:
                cur = new(start, end, sid)
            else:
                cur.end = end
        elif kind == "episode":
            if cur is None or cur.has_ep or (cur.show_id is not None and cur.show_id != sid):
                cur = new(start, end, sid)
            cur.has_ep = True
            cur.show_id, cur.show_name = sid, shows.get(sid, "")
            cur.title = (r["title"] or Path(r["path"]).stem).replace("_", " ").strip()
            cur.end = end
        else:  # commercials / bumpers / missing media extend the current slot
            if cur is None:
                cur = new(start, end, None)
            cur.end = end
        item_prog.append(len(progs) - 1)

    if len(_PROGRAM_CACHE) > 12:
        _PROGRAM_CACHE.clear()
    _PROGRAM_CACHE[airing.token] = (progs, item_prog)
    return progs, item_prog
